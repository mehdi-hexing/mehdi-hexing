/* Xray-Sing — Hysteria2 (UDP) + VLESS-WS (TCP) on one public port. */
const express = require("express");
const axios = require("axios");
const os = require("os");
const fs = require("fs");
const path = require("path");
const net = require("net");
const http = require("http");
const crypto = require("crypto");
const zlib = require("zlib");
const { exec, execSync, spawn, spawnSync } = require("child_process");

/* Ask the OS for a free local TCP port instead of hardcoding one. */
function getFreePort() {
    return new Promise((resolve, reject) => {
        const srv = net.createServer();
        srv.unref();
        srv.on("error", reject);
        srv.listen(0, "127.0.0.1", () => {
            const { port } = srv.address();
            srv.close(() => resolve(port));
        });
    });
}

/* Pull the SNI (server_name extension) out of a raw TLS ClientHello. */
function extractSNI(buffer) {
    try {
        if (buffer.length < 6 || buffer[0] !== 0x16 || buffer[1] !== 0x03) return null;
        let pos = 5;
        if (buffer[pos] !== 0x01) return null; // handshake type: ClientHello
        pos += 4;               // handshake header (type + 3-byte length)
        pos += 2;                // client_version
        pos += 32;               // random
        if (pos >= buffer.length) return null;
        const sessionIdLen = buffer[pos]; pos += 1 + sessionIdLen;
        if (pos + 2 > buffer.length) return null;
        const cipherSuitesLen = buffer.readUInt16BE(pos); pos += 2 + cipherSuitesLen;
        if (pos >= buffer.length) return null;
        const compMethodsLen = buffer[pos]; pos += 1 + compMethodsLen;
        if (pos + 2 > buffer.length) return null;
        const extTotalLen = buffer.readUInt16BE(pos); pos += 2;
        const extEnd = Math.min(pos + extTotalLen, buffer.length);
        while (pos + 4 <= extEnd) {
            const extType = buffer.readUInt16BE(pos); pos += 2;
            const extLen = buffer.readUInt16BE(pos); pos += 2;
            if (extType === 0x00) { // server_name
                let p = pos + 2;    // server_name_list length
                if (p + 3 > buffer.length) return null;
                p += 1;              // name_type (0 = host_name)
                const nameLen = buffer.readUInt16BE(p); p += 2;
                if (p + nameLen > buffer.length) return null;
                return buffer.toString("utf8", p, p + nameLen);
            }
            pos += extLen;
        }
        return null;
    } catch {
        return null;
    }
}

// CONFIGURATION
// Public port: TCP = HTTP panel + WS proxy; UDP = Hysteria2.
// VLESS-WS is local-only; Express proxies WebSocket upgrades to it.
const _publicPort = parseInt(process.env.SB_PORT || process.env.SERVER_PORT || process.env.PORT || "2705", 10);
const _defaultUuid = process.env.UUID || crypto.randomUUID();

/* Hardcoded data-directory resolver. */
function resolveDataDir() {
    if (process.env.FILE_PATH) return process.env.FILE_PATH;

    const candidates = [
        "/home/container/xray-sing",      // Katabump project root (persistent disk)
        path.join(__dirname, "xray-sing"), // next to this script, wherever it runs
        path.join(process.cwd(), "xray-sing"), // current working directory fallback
        path.join(os.tmpdir(), "xray-sing"),   // last resort (may be tmpfs/RAM)
    ];

    for (const dir of candidates) {
        try {
            fs.mkdirSync(dir, { recursive: true });
            fs.accessSync(dir, fs.constants.W_OK);
            return dir;
        } catch {
            // try next candidate
        }
    }
    // Nothing worked (shouldn't happen) — fall back to tmpdir anyway so
    // the app still gets a value instead of crashing here.
    return path.join(os.tmpdir(), "xray-sing");
}

const CONFIG = {
    UUID: _defaultUuid,
    FILE_PATH: resolveDataDir(),
    SUB_PATH: process.env.SUB_PATH || "sub",
    PORT: _publicPort,
    NAME: process.env.NAME || "vless",

    CFPORT: parseInt(process.env.CFPORT || "443", 10),

    // Argo enabled by default (set ENABLE_ARGO=0 to disable)
    ENABLE_ARGO: !(process.env.ENABLE_ARGO === "0" || process.env.ENABLE_ARGO === "false"),
    ARGO_DOMAIN: process.env.ARGO_DOMAIN || "",
    ARGO_AUTH: process.env.ARGO_AUTH || "",
    ARGO_PORT: parseInt(process.env.ARGO_PORT || "8001", 10),

    // Pinned back to the version this project already knew was fully
    // compatible before AnyTLS support existed (added in sing-box 1.
    // since AnyTLS/Naive/TUIC are no longer used, there's no reason to carry
    // the newer, larger release just for inbound types we don't run anymore.
    // Every protocol still offered here (Hysteria2, VLESS-WS/HTTPUpgrade,
    // ShadowTLS v3, REALITY, SS, SOCKS, HTTP) already worked on 1.
    // Override with SB_VERSION if you want a different pin.
    SB_VERSION: process.env.SB_VERSION || "1.11.15",
    SB_NAME: process.env.SB_NAME || "HY2",
    SB_PORT: _publicPort,
    VLESS_LOCAL_PORT: process.env.VLESS_LOCAL_PORT ? parseInt(process.env.VLESS_LOCAL_PORT, 10) : null,
    VLESS_HTTPUPGRADE_LOCAL_PORT: process.env.VLESS_HTTPUPGRADE_LOCAL_PORT ? parseInt(process.env.VLESS_HTTPUPGRADE_LOCAL_PORT, 10) : null,
    SB_UUID: process.env.SB_UUID || _defaultUuid,
    SB_SNI: process.env.SB_SNI || "www.google.com",
    SB_MASS_PROXY: process.env.SB_MASS_PROXY || "https://www.gstatic.com",
    SB_DOMAIN: process.env.SB_DOMAIN || process.env.DOMAIN || "",
    SB_HOST: process.env.SB_HOST || "127.0.0.1",
    // Set in Application.
    SB_OBFS_PWD: process.env.SB_OBFS_PWD || "",

    WS_PATH: process.env.WS_PATH || process.env.SB_UUID || _defaultUuid,
    VLESS_NAME: process.env.VLESS_NAME || "VLESS-WS",

    // VLESS + HTTPUpgrade (own local port, shares the public port
    // via the same upgrade-routing Express already does for WS)
    // Natively supported by official sing-box.
    // an Xray-core-only transport (also present in unofficial sing-box
    // forks like sing-box-lx, but not in upstream SagerNet/sing-box, which
    // is what this script downloads) — see the note where it's discussed.
    ENABLE_HTTPUPGRADE: !(process.env.ENABLE_HTTPUPGRADE === "0" || process.env.ENABLE_HTTPUPGRADE === "false"),
    HTTPUPGRADE_PATH: process.env.HTTPUPGRADE_PATH || `/${process.env.SB_UUID || _defaultUuid}-hu`,
    HTTPUPGRADE_NAME: process.env.HTTPUPGRADE_NAME || "VLESS-HTTPUpgrade",
    // VLESS_LOCAL_PORT (below) stays as-is unless overridden by env; SS/SOCKS
    // and the new HTTPUpgrade local port are resolved to a free OS-assigned
    // port at runtime in SbManager.

    // VLESS + XHTTP — needs Xray-core, sing-box doesn't implement it
    // (see the note next to XRAY_DOWNLOAD_URL).
    // reverse-proxied from Express under XHTTP_PATH (see createApp()).
    ENABLE_XHTTP: !(process.env.ENABLE_XHTTP === "0" || process.env.ENABLE_XHTTP === "false"),
    XRAY_LOCAL_PORT: process.env.XRAY_LOCAL_PORT ? parseInt(process.env.XRAY_LOCAL_PORT, 10) : null,
    XHTTP_PATH: process.env.XHTTP_PATH || `/${process.env.SB_UUID || _defaultUuid}-xh`,
    XHTTP_MODE: process.env.XHTTP_MODE || "auto",
    XHTTP_NAME: process.env.XHTTP_NAME || "VLESS-XHTTP",

    // Shadowsocks (localhost only, reached via the port mux)
    ENABLE_SS: !(process.env.ENABLE_SS === "0" || process.env.ENABLE_SS === "false"),
    SS_PORT: process.env.SS_PORT ? parseInt(process.env.SS_PORT, 10) : null,
    // "aes-256-gcm" accepts any plain-text password (unlike 2022-blake3 ,
    // which requires a base64 pre-shared key of a fixed byte length).
    SS_METHOD: process.env.SS_METHOD || "aes-256-gcm",
    SS_PASSWORD: process.env.SS_PASSWORD || _defaultUuid,
    SS_NAME: process.env.SS_NAME || "SS",

    // SOCKS5 (localhost only, reached via the port mux)
    // No built-in encryption/obfuscation — fine for local/LAN use behind
    // something else, NOT recommended as a public censorship-evasion link.
    ENABLE_SOCKS: !(process.env.ENABLE_SOCKS === "0" || process.env.ENABLE_SOCKS === "false"),
    SOCKS_PORT: process.env.SOCKS_PORT ? parseInt(process.env.SOCKS_PORT, 10) : null,
    SOCKS_USER: process.env.SOCKS_USER || "",
    SOCKS_PASS: process.env.SOCKS_PASS || "",
    SOCKS_NAME: process.env.SOCKS_NAME || "SOCKS5",

    // VLESS + REALITY (own local port, raw TLS ClientHello passed
    // straight through the same public port by the TCP mux,
    // disambiguated from ShadowTLS by SNI)
    // Kept enabled: it not working inside Iran specifically is a reason to
    // ALSO offer ShadowTLS (below), not a reason to remove REALITY for
    // every other country where its handshake isn't filtered.
    ENABLE_REALITY: !(process.env.ENABLE_REALITY === "0" || process.env.ENABLE_REALITY === "false"),
    REALITY_PORT: process.env.REALITY_PORT ? parseInt(process.env.REALITY_PORT, 10) : null,
    REALITY_TARGET: process.env.REALITY_TARGET || "www.microsoft.com",
    REALITY_TARGET_PORT: parseInt(process.env.REALITY_TARGET_PORT || "443", 10),
    REALITY_SHORT_ID: process.env.REALITY_SHORT_ID || "",
    REALITY_PRIVATE_KEY: "",
    REALITY_PUBLIC_KEY: "",
    REALITY_NAME: process.env.REALITY_NAME || "VLESS-REALITY",

    // ShadowTLS v3, pure (in front of VLESS, NOT combined with
    // Shadowsocks) — own local port; the front TCP mux forwards
    // raw TLS ClientHello bytes to it by SNI.
    // The practical native-sing-box option for places (e.
    // where REALITY's handshake specifically gets fingerprinted/blocked:
    // it performs a REAL TLS handshake with a real site for anyone who
    // doesn't know the password, diverting only authenticated traffic.
    // Kept deliberately "pure" (VLESS behind it, not the classic
    // ShadowTLS+Shadowsocks-2022 combo) — one less moving part per link.
    ENABLE_SHADOWTLS_VLESS: !(process.env.ENABLE_SHADOWTLS_VLESS === "0" || process.env.ENABLE_SHADOWTLS_VLESS === "false"),
    SHADOWTLS_VLESS_PORT: process.env.SHADOWTLS_VLESS_PORT ? parseInt(process.env.SHADOWTLS_VLESS_PORT, 10) : null,
    SHADOWTLS_VLESS_SNI: process.env.SHADOWTLS_VLESS_SNI || "www.microsoft.com",
    SHADOWTLS_VLESS_PASSWORD: process.env.SHADOWTLS_VLESS_PASSWORD || _defaultUuid,
    SHADOWTLS_VLESS_NAME: process.env.SHADOWTLS_VLESS_NAME || "ShadowTLS-VLESS",

    // Plain HTTP proxy — native sing-box "http" inbound (RFC 7231
    // CONNECT + absolute-form GET), muxed onto the shared public
    // port by request-line shape, not TLS, so no SNI needed here)
    ENABLE_HTTP_PROXY: !(process.env.ENABLE_HTTP_PROXY === "0" || process.env.ENABLE_HTTP_PROXY === "false"),
    HTTP_PROXY_PORT: process.env.HTTP_PROXY_PORT ? parseInt(process.env.HTTP_PROXY_PORT, 10) : null,
    HTTP_PROXY_USER: process.env.HTTP_PROXY_USER || "",
    HTTP_PROXY_PASS: process.env.HTTP_PROXY_PASS || "",
    HTTP_PROXY_NAME: process.env.HTTP_PROXY_NAME || "HTTP",

    BOT_URL: process.env.BOT_URL || "",

    // Cap each proxy engine's CPU usage with `cpulimit` (percent of ONE
    // core, e.
    // sustains CPU above a threshold.
    // a warning is logged once instead of silently doing nothing.
    CPU_LIMIT_PERCENT: process.env.CPU_LIMIT_PERCENT ? parseInt(process.env.CPU_LIMIT_PERCENT, 10) : null
};

// CONSTANTS
const COLORS = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    dim: '\x1b[2m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m'
};

// SYSTEM VARIABLES
const ARCH = (() => {
    const arch = os.arch();
    return (arch === 'arm' || arch === 'arm64' || arch === 'aarch64') ? 'arm64' : 'amd64';
})();

const TAR_NAME = `sing-box-${CONFIG.SB_VERSION}-linux-${ARCH}.tar.gz`;
const DOWNLOAD_URL = process.env.SB_URL ||
    `https://github.com/SagerNet/sing-box/releases/download/v${CONFIG.SB_VERSION}/${TAR_NAME}`;

// Xray-core (needed for XHTTP, and now shared/reused for Argo too — see
// XManager.
// notes where CONFIG.
// sing-box's.
const XRAY_ARCH = ARCH === 'arm64' ? 'arm64-v8a' : '64';
const XRAY_ZIP_NAME = `Xray-linux-${XRAY_ARCH}.zip`;
// No version pinned by default — "latest/download" always resolves to
// whatever XTLS actually ships right now, so we don't hardcode a tag that
// could go stale.
// older) release if disk space on the host is tight — combined with the
// sing-box pin above and no longer downloading a second Xray-core copy for
// Argo, this is the full "free up room for Argo" story on constrained hosts.
const XRAY_DOWNLOAD_URL = process.env.XRAY_URL ||
    (process.env.XRAY_VERSION
        ? `https://github.com/XTLS/Xray-core/releases/download/v${process.env.XRAY_VERSION}/${XRAY_ZIP_NAME}`
        : `https://github.com/XTLS/Xray-core/releases/latest/download/${XRAY_ZIP_NAME}`);

// File paths
const PATHS = {
    SB_BASE_DIR: path.join(CONFIG.FILE_PATH, "sb"),
    SB_CERT_DIR: path.join(CONFIG.FILE_PATH, "sb", "cert"),
    SB_CERT_PATH: path.join(CONFIG.FILE_PATH, "sb", "cert", "cert.pem"),
    SB_KEY_PATH: path.join(CONFIG.FILE_PATH, "sb", "cert", "key.pem"),
    SB_JSON: path.join(CONFIG.FILE_PATH, "sb", "sb.json"),
    SB_BIN: path.join(CONFIG.FILE_PATH, "sb", "sb"),
    SB_LOG_FILE: path.join(CONFIG.FILE_PATH, "sb", "sb.log"),
    X_CONFIG: path.join(CONFIG.FILE_PATH, 'config.json'),
    BOOT_LOG: path.join(CONFIG.FILE_PATH, 'boot.log'),
    XRAY_BASE_DIR: path.join(CONFIG.FILE_PATH, "xray"),
    XRAY_BIN: path.join(CONFIG.FILE_PATH, "xray", "xray"),
    XRAY_JSON: path.join(CONFIG.FILE_PATH, "xray", "xray.json"),
    XRAY_LOG_FILE: path.join(CONFIG.FILE_PATH, "xray", "xray.log")
};

// Global state
const state = {
    xLinks: [],
    sboxLinks: [],          // Hysteria2 links
    vlessWsLinks: [],       // VLESS-WS links (same port as HY2)
    vlessHuLinks: [],       // VLESS-HTTPUpgrade links (same port as HY2)
    vlessXhttpLinks: [],    // VLESS-XHTTP links (Xray-core, reverse-proxied)
    ssLinks: [],            // Shadowsocks links (muxed onto the same port)
    socksLinks: [],         // SOCKS5 links (muxed onto the same port)
    realityLinks: [],       // VLESS-REALITY links (muxed onto the same port)
    shadowtlsVlessLinks: [],// ShadowTLS-VLESS links (pure ShadowTLS, muxed onto the same port)
    httpProxyLinks: [],     // Plain HTTP proxy links (sing-box http inbound, muxed onto the same port)
    xBase64: "",
    sboxBase64: "",
    vlessWsBase64: "",
    vlessHuBase64: "",
    ssBase64: "",
    sbProcess: null,
    xrayProcess: null,
    xCoreProcess: null,
    cloudflaredProcess: null
};

// LOGGER
// QUIET=1 — only errors.
class Logger {
    static quiet = process.env.QUIET === "1" || process.env.QUIET === "true";

    static info(message) {
        if (!this.quiet) console.log(`${COLORS.cyan}[i] ${message}${COLORS.reset}`);
    }

    static success(message) {
        if (!this.quiet) console.log(`${COLORS.green}[OK] ${message}${COLORS.reset}`);
    }

    static warning(message) {
        if (!this.quiet) console.log(`${COLORS.yellow}[!] ${message}${COLORS.reset}`);
    }

    static error(message) {
        console.log(`${COLORS.red}[X] ${message}${COLORS.reset}`);
    }

    static step(message) {
        if (!this.quiet) console.log(`${COLORS.blue}-> ${message}${COLORS.reset}`);
    }

    static header(message) {
        if (!this.quiet) {
            console.log(`\n${COLORS.bright}${COLORS.magenta}${"=".repeat(56)}${COLORS.reset}`);
            console.log(`${COLORS.bright}${COLORS.magenta}  ${message}${COLORS.reset}`);
            console.log(`${COLORS.bright}${COLORS.magenta}${"=".repeat(56)}${COLORS.reset}\n`);
        }
    }

    static divider() {
        if (!this.quiet) console.log(`${COLORS.dim}${"-".repeat(56)}${COLORS.reset}`);
    }

    static config(key, value) {
        if (!this.quiet) console.log(`  ${COLORS.cyan}${key}:${COLORS.reset} ${COLORS.yellow}${value}${COLORS.reset}`);
    }

    /* Clear terminal (ANSI + fallback for panel log viewers) */
    static clearConsole() {
        try {
            if (typeof console.clear === "function") console.clear();
        } catch { /* ignore */ }
        try {
            process.stdout.write("\x1B[2J\x1B[3J\x1B[H\x1Bc");
        } catch { /* ignore */ }
        // Panels that ignore ANSI still get a visual break
        console.log("\n".repeat(8));
    }
}

// SYSTEM UTILITIES
class SystemUtils {
    /* Get public IP address synchronously */
    static getPublicIpSync() {
        const ipRegex = /\b((25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(\.(?!$)|$)){4}\b/;
        const curlCandidates = [
            "https://ifconfig.co",
            "https://ifconfig.me/ip",
            "https://api.ipify.org",
            "https://ifconfig.io/ip",
        ];

        for (const url of curlCandidates) {
            try {
                const result = spawnSync("curl", ["-sS", url], {
                    encoding: "utf8",
                    timeout: 8000,
                });
                if (result.status === 0 && result.stdout) {
                    const match = result.stdout.trim().match(ipRegex);
                    if (match) return match[0];
                }
            } catch {
                // Continue to next candidate
            }
        }

        try {
            const result = spawnSync("dig", ["+short", "myip.opendns.com", "@resolver1.opendns.com"], {
                encoding: "utf8",
                timeout: 8000,
            });
            if (result.status === 0 && result.stdout) {
                const match = result.stdout.trim().match(ipRegex);
                if (match) return match[0];
            }
        } catch {
            // Fall through
        }

        return null;
    }

    /* Get ISP / location label for node name (e. */
    static async getISPInfo() {
        const sanitize = (s) => String(s || '')
            .replace(/[^\w.\-]+/g, '_')
            .replace(/_+/g, '_')
            .replace(/^_|_$/g, '')
            .slice(0, 48) || 'UNKNOWN';

        // 1) Cloudflare speed meta (JSON)
        try {
            const r = spawnSync('curl', ['-sS', '--max-time', '6', 'https://speed.cloudflare.com/meta'], {
                encoding: 'utf8',
                timeout: 8000
            });
            if (r.status === 0 && r.stdout) {
                const j = JSON.parse(r.stdout);
                // Typical fields: colo, city, clientIp, asOrganization / asn
                const org = j.asOrganization || j.asn || j.clientAsn || '';
                const city = j.city || j.colo || '';
                const label = [org, city].filter(Boolean).join('-');
                if (label) return sanitize(label);
            }
        } catch {
            // continue
        }

        // 2) ipinfo.
        try {
            const r = spawnSync('curl', ['-sS', '--max-time', '6', 'https://ipinfo.io/json'], {
                encoding: 'utf8',
                timeout: 8000
            });
            if (r.status === 0 && r.stdout) {
                const j = JSON.parse(r.stdout);
                const label = [j.org, j.city || j.country].filter(Boolean).join('-');
                if (label) return sanitize(label);
            }
        } catch {
            // continue
        }

        // 3) ip-api.
        try {
            const r = spawnSync('curl', ['-sS', '--max-time', '6', 'http://ip-api.com/json/?fields=status,isp,org,as,city,country'], {
                encoding: 'utf8',
                timeout: 8000
            });
            if (r.status === 0 && r.stdout) {
                const j = JSON.parse(r.stdout);
                if (j.status === 'success') {
                    const label = [j.isp || j.org || j.as, j.city || j.country].filter(Boolean).join('-');
                    if (label) return sanitize(label);
                }
            }
        } catch {
            // continue
        }

        return 'UNKNOWN';
    }

    /* Ensure directory exists */
    static ensureDirectory(dirPath) {
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
            Logger.success(`Directory created: ${dirPath}`);
        }
    }

    /* Free disk space (in MB) available on the filesystem containing */
    static getFreeDiskMB(dirPath) {
        try {
            const result = spawnSync("df", ["-Pk", dirPath], { encoding: "utf8", timeout: 5000 });
            if (result.status !== 0 || !result.stdout) return null;
            const lines = result.stdout.trim().split("\n");
            const fields = lines[lines.length - 1].trim().split(/\s+/);
            const availableKB = parseInt(fields[3], 10);
            if (Number.isNaN(availableKB)) return null;
            return Math.floor(availableKB / 1024);
        } catch {
            return null;
        }
    }

    /* Whether a command exists on PATH (cached — checked often). */
    static commandExists(cmd) {
        if (!this._cmdCache) this._cmdCache = {};
        if (cmd in this._cmdCache) return this._cmdCache[cmd];
        const result = spawnSync("which", [cmd], { timeout: 5000 });
        const exists = result.status === 0;
        this._cmdCache[cmd] = exists;
        return exists;
    }

    /* If CONFIG. */
    static withCpuLimit(binPath, args) {
        if (!CONFIG.CPU_LIMIT_PERCENT) return { command: binPath, args, wrapped: false };
        if (!this.commandExists("cpulimit")) {
            if (!this._cpulimitWarned) {
                this._cpulimitWarned = true;
                Logger.info("cpulimit not installed — using the built-in CPU watchdog (SIGSTOP/SIGCONT) instead, no package install needed.");
            }
            return { command: binPath, args, wrapped: false };
        }
        return { command: "cpulimit", args: ["-l", String(CONFIG.CPU_LIMIT_PERCENT), "--", binPath, ...args], wrapped: true };
    }

    /* Cached CLK_TCK (clock ticks/sec) used to convert /proc/[pid]/stat times to seconds. */
    static getClkTck() {
        if (this._clkTck) return this._clkTck;
        try {
            const r = spawnSync("getconf", ["CLK_TCK"], { encoding: "utf8", timeout: 3000 });
            const v = parseInt((r.stdout || "").trim(), 10);
            this._clkTck = (r.status === 0 && v > 0) ? v : 100;
        } catch {
            this._clkTck = 100; // standard default on Linux
        }
        return this._clkTck;
    }

    /* Total CPU ticks (utime+stime) a process has used, from /proc/[pid]/stat. */
    static readProcCpuTicks(pid) {
        try {
            const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf8");
            // comm (2nd field) is in parens and may itself contain spaces/parens,
            // so split from the LAST ')' rather than assuming fixed field widths.
            const afterComm = stat.slice(stat.lastIndexOf(")") + 2).trim().split(/\s+/);
            // afterComm[0] = state (field 3); utime is field 14 -> index 11 here, stime field 15 -> inde
            const utime = parseInt(afterComm[11], 10);
            const stime = parseInt(afterComm[12], 10);
            if (Number.isNaN(utime) || Number.isNaN(stime)) return null;
            return utime + stime;
        } catch {
            return null;
        }
    }

    static isPidAlive(pid) {
        try {
            process.kill(pid, 0);
            return true;
        } catch {
            return false;
        }
    }

    /* Built-in cpulimit replacement for hosts where the `cpulimit` binary */
    static startCpuWatchdog(pid, label, limitPercent, periodMs = 100) {
        if (!pid || !limitPercent) return null;
        if (!fs.existsSync(`/proc/${pid}/stat`)) {
            Logger.warning(`CPU watchdog: /proc/${pid}/stat not readable — can't cap ${label} on this host`);
            return null;
        }

        const clkTck = this.getClkTck();
        const onMs = periodMs * (limitPercent / 100);
        const offMs = periodMs - onMs;

        try {
            process.kill(pid, "SIGSTOP");
        } catch {
            return null; // already gone
        }

        let stopped = true;
        let cancelled = false;

        (async () => {
            while (!cancelled && this.isPidAlive(pid)) {
                if (stopped) {
                    try { process.kill(pid, "SIGCONT"); } catch { break; }
                    stopped = false;
                }
                const before = this.readProcCpuTicks(pid);
                await new Promise(r => setTimeout(r, onMs));
                if (cancelled || !this.isPidAlive(pid)) break;
                const after = this.readProcCpuTicks(pid);
                if (before === null || after === null) continue;
                const usedOnMs = ((after - before) / clkTck) * 1000;
                if (usedOnMs > onMs * 0.85) {
                    try {
                        process.kill(pid, "SIGSTOP");
                        stopped = true;
                    } catch {
                        break;
                    }
                    await new Promise(r => setTimeout(r, offMs));
                }
            }
        })();

        Logger.info(`CPU watchdog active for ${label}: capped at ${limitPercent}% (throttled from launch)`);
        return { cancel: () => { cancelled = true; try { process.kill(pid, "SIGCONT"); } catch { /* ignore */ } } };
    }

    /* Download file with progress */
    static downloadFile(fileName, fileUrl) {
        return new Promise((resolve, reject) => {
            const filePath = path.join(CONFIG.FILE_PATH, fileName);

            // Skip download only if a reasonably sized binary already exists
            try {
                const minSize = (fileName === "web" || fileName === "bot") ? 500 * 1024 : 1024;
                if (fs.existsSync(filePath) && fs.statSync(filePath).size >= minSize) {
                    fs.chmodSync(filePath, 0o755);
                    Logger.info(`Already present, skip download: ${fileName}`);
                    return resolve(fileName);
                }
            } catch {
                // continue to download
            }

            const writer = fs.createWriteStream(filePath);

            axios({
                method: 'get',
                url: fileUrl,
                responseType: 'stream',
                timeout: 30000
            })
            .then(response => {
                response.data.pipe(writer);

                writer.on('finish', () => {
                    writer.close();
                    fs.chmodSync(filePath, 0o755);
                    Logger.success(`Downloaded: ${fileName}`);
                    resolve(fileName);
                });

                writer.on('error', err => {
                    fs.unlink(filePath, () => {});
                    if (err.code === 'ENOSPC') {
                        const freeMB = SystemUtils.getFreeDiskMB(CONFIG.FILE_PATH);
                        reject(`Download error ${fileName}: disk is full writing to ${CONFIG.FILE_PATH}` +
                            (freeMB !== null ? ` (~${freeMB}MB free)` : '') +
                            `. Free up space, point FILE_PATH at a volume with more room, or set ENABLE_ARGO=0 / ENABLE_XHTTP=0 to skip binaries you don't need.`);
                        return;
                    }
                    reject(`Download error ${fileName}: ${err.message}`);
                });
            })
            .catch(err => {
                reject(`Download error ${fileName}: ${err.message}`);
            });
        });
    }

    /* Apply system optimizations for better performance */
    static applySystemOptimizations() {
        Logger.step("Applying system optimizations for maximum performance...");

        try {
            const optimizations = [
                // TCP optimizations
                'sysctl -w net.core.rmem_max=268435456',
                'sysctl -w net.core.wmem_max=268435456',
                'sysctl -w net.ipv4.tcp_rmem="4096 87380 268435456"',
                'sysctl -w net.ipv4.tcp_wmem="4096 16384 268435456"',
                'sysctl -w net.core.netdev_max_backlog=100000',
                'sysctl -w net.core.somaxconn=65535',
                'sysctl -w net.ipv4.tcp_max_syn_backlog=65535',

                // BBR congestion control
                'sysctl -w net.ipv4.tcp_congestion_control=bbr',
                'sysctl -w net.ipv4.tcp_fastopen=3',
                'sysctl -w net.core.default_qdisc=fq_codel',

                // File descriptor limits
                'sysctl -w fs.file-max=2097152',
                'sysctl -w fs.nr_open=2097152',

                // Memory optimizations
                'sysctl -w net.ipv4.tcp_mem="786432 2097152 3145728"',
                'sysctl -w net.ipv4.udp_mem="786432 2097152 3145728"',

                // Additional optimizations
                'sysctl -w net.ipv4.tcp_slow_start_after_idle=0',
                'sysctl -w net.ipv4.tcp_tw_reuse=1',
                'sysctl -w net.ipv4.tcp_fin_timeout=30',
                'sysctl -w net.ipv4.tcp_keepalive_time=1200',
                'sysctl -w net.ipv4.tcp_keepalive_intvl=30',
                'sysctl -w net.ipv4.tcp_keepalive_probes=3'
            ];

            let applied = 0;
            for (const cmd of optimizations) {
                try {
                    execSync(cmd, { stdio: 'ignore' });
                    applied++;
                } catch {
                    // Ignore errors if no root privileges
                }
            }

            if (applied > 0) {
                Logger.success(`Applied ${applied} system optimizations`);
            } else {
                Logger.warning("Could not apply system optimizations (root privileges required)");
            }
        } catch (error) {
            Logger.warning("Error applying system optimizations");
        }
    }
}

// SB MANAGER (Hysteria2 + VLESS-WS)
class SbManager {
    /* Get server host (domain, IP, or fallback) */
    static async getServerHost() {
        if (CONFIG.SB_DOMAIN) {
            Logger.info(`Using domain: ${CONFIG.SB_DOMAIN}`);
            return CONFIG.SB_DOMAIN;
        }

        const publicIp = SystemUtils.getPublicIpSync();
        if (publicIp) {
            Logger.info(`Using public IP: ${publicIp}`);
            return publicIp;
        }

        Logger.warning(`Using fallback host: ${CONFIG.SB_HOST}`);
        return CONFIG.SB_HOST;
    }

    /* Ensure TLS certificates exist (used by Hysteria2) */
    static ensureCertificates() {
        SystemUtils.ensureDirectory(PATHS.SB_CERT_DIR);

        // Use external certificates if provided
        if (process.env.EXTERNAL_CERT && process.env.EXTERNAL_KEY &&
            fs.existsSync(process.env.EXTERNAL_CERT) && fs.existsSync(process.env.EXTERNAL_KEY)) {
            Logger.info("Using external TLS certificates");
            return {
                cert: process.env.EXTERNAL_CERT,
                key: process.env.EXTERNAL_KEY
            };
        }

        // Generate self-signed certificates
        if (!fs.existsSync(PATHS.SB_CERT_PATH) || !fs.existsSync(PATHS.SB_KEY_PATH)) {
            Logger.step("Generating self-signed TLS certificate");
            const result = spawnSync("openssl", [
                "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-subj", `/CN=${CONFIG.SB_SNI}`,
                "-keyout", PATHS.SB_KEY_PATH,
                "-out", PATHS.SB_CERT_PATH,
                "-days", "365",
            ]);

            if (result.status !== 0) {
                Logger.error("Failed to generate TLS certificate");
                return { cert: null, key: null };
            }
            Logger.success("TLS certificate generated");
        }

        return { cert: PATHS.SB_CERT_PATH, key: PATHS.SB_KEY_PATH };
    }

    /* Ensure sb binary is downloaded and ready */
    static ensureBinary() {
        if (fs.existsSync(PATHS.SB_BIN)) {
            // A cached binary from an older CONFIG.
            // previous run against a persistent FILE_PATH) can be missing
            // inbound types the current config asks for (this is exactly how
            // "unknown inbound type: shadowtls" could happen against a stale
            // binary even after bumping SB_VERSION).
            // reports the version we want; if not, drop it and re-download.
            const versionCheck = spawnSync(PATHS.SB_BIN, ["version"], { encoding: "utf8", timeout: 10000 });
            const reportedVersion = versionCheck.stdout && versionCheck.stdout.match(/version\s+([0-9][^\s,]*)/i);
            if (versionCheck.status === 0 && reportedVersion && reportedVersion[1] === CONFIG.SB_VERSION) {
                return true;
            }
            Logger.warning(`Cached sb binary is ${reportedVersion ? reportedVersion[1] : "unknown version"}, expected ${CONFIG.SB_VERSION} — re-downloading`);
            try { fs.unlinkSync(PATHS.SB_BIN); } catch { /* ignore */ }
        }

        SystemUtils.ensureDirectory(PATHS.SB_BASE_DIR);
        Logger.step(`Downloading sb (${ARCH})`);

        const freeMB = SystemUtils.getFreeDiskMB(PATHS.SB_BASE_DIR);
        if (freeMB !== null && freeMB < 100) {
            Logger.warning(`Low disk space before downloading sb: ~${freeMB}MB free in ${PATHS.SB_BASE_DIR}. Download may fail with ENOSPC.`);
        }

        const tarPath = path.join(PATHS.SB_BASE_DIR, TAR_NAME);

        // Download sb
        const curlResult = spawnSync("curl", ["-L", "-sS", "-o", tarPath, DOWNLOAD_URL], {
            timeout: 60000
        });

        if (curlResult.status !== 0) {
            Logger.error("Failed to download sb");
            return false;
        }

        // Extract archive
        const tarResult = spawnSync("tar", ["-xzf", tarPath, "-C", PATHS.SB_BASE_DIR]);
        if (tarResult.status !== 0) {
            Logger.error("Failed to extract sb archive");
            return false;
        }

        // Move binary to correct location
        const extractedDir = path.join(PATHS.SB_BASE_DIR, `sing-box-${CONFIG.SB_VERSION}-linux-${ARCH}`);
        if (fs.existsSync(path.join(extractedDir, "sing-box"))) {
            fs.renameSync(path.join(extractedDir, "sing-box"), PATHS.SB_BIN);
            spawnSync("chmod", ["+x", PATHS.SB_BIN]);
            // Free disk: remove archive and extracted folder
            try {
                fs.unlinkSync(tarPath);
                fs.rmSync(extractedDir, { recursive: true, force: true });
            } catch {
                // ignore cleanup errors
            }
            Logger.success("sb installed successfully");
            return true;
        }

        Logger.error("sb binary not found in archive");
        return false;
    }

    /* Create sing-box configuration */
    static writeConfiguration(cert, key) {
        Logger.step("Creating sb configuration (Hysteria2 + VLESS-WS)");

        // Normalize WS path: must start with / for the transport
        const wsPath = CONFIG.WS_PATH.startsWith('/') ? CONFIG.WS_PATH : `/${CONFIG.WS_PATH}`;
        const huPath = CONFIG.HTTPUPGRADE_PATH.startsWith('/') ? CONFIG.HTTPUPGRADE_PATH : `/${CONFIG.HTTPUPGRADE_PATH}`;

        const config = {
            "log": {
                "level": "info",
                "timestamp": true
            },
            "inbounds": [
                // Hysteria2 (UDP / QUIC) on public port
                {
                    "type": "hysteria2",
                    "tag": "hy2-in",
                    "listen": "::",
                    "listen_port": CONFIG.SB_PORT,
                    "users": [
                        {
                            "password": CONFIG.SB_UUID
                        }
                    ],
                    "tls": {
                        "enabled": true,
                        "server_name": CONFIG.SB_SNI,
                        "alpn": ["h3"],
                        "certificate_path": cert,
                        "key_path": key
                    },
                    "obfs": {
                        "type": "salamander",
                        "password": CONFIG.SB_OBFS_PWD
                    },
                    "masquerade": {
                        "type": "proxy",
                        "url": CONFIG.SB_MASS_PROXY,
                        "rewrite_host": true
                    },
                    "ignore_client_bandwidth": false,
                    "up_mbps": 100,
                    "down_mbps": 100
                },
                // VLESS + WebSocket (TCP) on localhost only
                // Public clients connect to Express on the public port; Express
                // proxies WebSocket upgrades to this inbound.
                {
                    "type": "vless",
                    "tag": "vless-ws-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.VLESS_LOCAL_PORT,
                    "users": [
                        {
                            "uuid": CONFIG.SB_UUID,
                            "flow": ""
                        }
                    ],
                    "tls": {
                        "enabled": false
                    },
                    "transport": {
                        "type": "ws",
                        "path": wsPath,
                        "max_early_data": 2560,
                        "early_data_header_name": "Sec-WebSocket-Protocol"
                    }
                },
                // VLESS + HTTPUpgrade (TCP) on localhost only
                // Same idea as VLESS-WS above, but a lighter transport (plain
                // HTTP Upgrade handshake, no WebSocket framing) — natively
                // supported by official sing-box.
                // the same httpServer "upgrade" handler (see startServer()).
                ...(CONFIG.ENABLE_HTTPUPGRADE ? [{
                    "type": "vless",
                    "tag": "vless-hu-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.VLESS_HTTPUPGRADE_LOCAL_PORT,
                    "users": [
                        {
                            "uuid": CONFIG.SB_UUID,
                            "flow": ""
                        }
                    ],
                    "tls": {
                        "enabled": false
                    },
                    "transport": {
                        "type": "httpupgrade",
                        "path": huPath
                    }
                }] : []),
                // Shadowsocks (localhost only — reached via the
                // port-multiplexer on the public port, see startServer)
                ...(CONFIG.ENABLE_SS ? [{
                    "type": "shadowsocks",
                    "tag": "ss-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.SS_PORT,
                    "method": CONFIG.SS_METHOD,
                    "password": CONFIG.SS_PASSWORD
                }] : []),
                // SOCKS5 (localhost only — same multiplexer)
                ...(CONFIG.ENABLE_SOCKS ? [{
                    "type": "socks",
                    "tag": "socks-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.SOCKS_PORT,
                    "users": CONFIG.SOCKS_USER
                        ? [{ "username": CONFIG.SOCKS_USER, "password": CONFIG.SOCKS_PASS }]
                        : []
                }] : []),
                // VLESS + REALITY (localhost only — raw TLS
                // ClientHello bytes piped through by the mux,
                // disambiguated from ShadowTLS by SNI)
                ...(CONFIG.ENABLE_REALITY ? [{
                    "type": "vless",
                    "tag": "vless-reality-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.REALITY_PORT,
                    "users": [
                        {
                            "uuid": CONFIG.SB_UUID,
                            "flow": "xtls-rprx-vision"
                        }
                    ],
                    "tls": {
                        "enabled": true,
                        "server_name": CONFIG.REALITY_TARGET,
                        "alpn": ["http/1.1"],
                        "reality": {
                            "enabled": true,
                            "handshake": {
                                "server": CONFIG.REALITY_TARGET,
                                "server_port": CONFIG.REALITY_TARGET_PORT
                            },
                            "private_key": CONFIG.REALITY_PRIVATE_KEY,
                            "short_id": [CONFIG.REALITY_SHORT_ID]
                        }
                    }
                }] : []),
                // ShadowTLS v3 + VLESS, pure (localhost only — raw
                // TLS ClientHello bytes piped through by the mux,
                // routed here by SNI; no Shadowsocks combo)
                // Alongside REALITY (kept — see the comment on ENABLE_REALITY
                // above), ShadowTLS is offered as the option that keeps working
                // in networks where REALITY's handshake specifically gets
                // fingerprinted: it performs a REAL TLS handshake with a real
                // site (SHADOWTLS_VLESS_SNI) for anyone without the password.
                ...(CONFIG.ENABLE_SHADOWTLS_VLESS ? [
                    {
                        "type": "shadowtls",
                        "tag": "shadowtls-vless-in",
                        "listen": "127.0.0.1",
                        "listen_port": CONFIG.SHADOWTLS_VLESS_PORT,
                        "version": 3,
                        "users": [
                            { "name": CONFIG.SB_UUID, "password": CONFIG.SHADOWTLS_VLESS_PASSWORD }
                        ],
                        "handshake": {
                            "server": CONFIG.SHADOWTLS_VLESS_SNI,
                            "server_port": 443
                        },
                        "strict_mode": true,
                        "detour": "vless-shadowtls-detour-in"
                    },
                    {
                        "type": "vless",
                        "tag": "vless-shadowtls-detour-in",
                        "users": [
                            { "uuid": CONFIG.SB_UUID, "flow": "" }
                        ]
                    }
                ] : []),
                // Plain HTTP proxy (localhost only — sing-box's own
                // native "http" inbound type; muxed onto the public
                // port by request-line shape, see startServer())
                ...(CONFIG.ENABLE_HTTP_PROXY ? [{
                    "type": "http",
                    "tag": "http-in",
                    "listen": "127.0.0.1",
                    "listen_port": CONFIG.HTTP_PROXY_PORT,
                    "users": CONFIG.HTTP_PROXY_USER
                        ? [{ "username": CONFIG.HTTP_PROXY_USER, "password": CONFIG.HTTP_PROXY_PASS }]
                        : []
                }] : [])
            ],
            "outbounds": [
                {
                    "type": "direct",
                    "tag": "direct"
                },
                {
                    "type": "block",
                    "tag": "block"
                }
            ]
        };

        fs.writeFileSync(PATHS.SB_JSON, JSON.stringify(config, null, 2));
        let sbMsg = `sb config: HY2 UDP :${CONFIG.SB_PORT} + VLESS-WS 127.0.0.1:${CONFIG.VLESS_LOCAL_PORT}`;
        if (CONFIG.ENABLE_HTTPUPGRADE) sbMsg += ` + VLESS-HTTPUpgrade 127.0.0.1:${CONFIG.VLESS_HTTPUPGRADE_LOCAL_PORT}`;
        if (CONFIG.ENABLE_SS) sbMsg += ` + SS :${CONFIG.SS_PORT}`;
        if (CONFIG.ENABLE_SOCKS) sbMsg += ` + SOCKS5 :${CONFIG.SOCKS_PORT}`;
        if (CONFIG.ENABLE_SHADOWTLS_VLESS) sbMsg += ` + ShadowTLS-VLESS 127.0.0.1:${CONFIG.SHADOWTLS_VLESS_PORT}`;
        if (CONFIG.ENABLE_REALITY) sbMsg += ` + VLESS-REALITY 127.0.0.1:${CONFIG.REALITY_PORT}`;
        if (CONFIG.ENABLE_HTTP_PROXY) sbMsg += ` + HTTP 127.0.0.1:${CONFIG.HTTP_PROXY_PORT}`;
        Logger.success(sbMsg);
    }

    /* Start sb process */
    static start() {
        Logger.step("Starting sb...");

        if (!fs.existsSync(PATHS.SB_BIN)) {
            Logger.error("sb binary not found");
            return null;
        }

        // Validate configuration first
        const checkResult = spawnSync(PATHS.SB_BIN, ["check", "-c", PATHS.SB_JSON], {
            encoding: 'utf8'
        });

        if (checkResult.status !== 0) {
            Logger.error(`sb configuration error: ${checkResult.stderr}`);
            return null;
        }

        Logger.success("sb configuration validated");

        // Start sb process
        const logFile = fs.openSync(PATHS.SB_LOG_FILE, 'a');
        const { command: sbCommand, args: sbArgs, wrapped: sbWrapped } = SystemUtils.withCpuLimit(PATHS.SB_BIN, ["run", "-c", PATHS.SB_JSON]);
        const child = spawn(sbCommand, sbArgs, {
            stdio: ['ignore', logFile, logFile],
            detached: false,
        });
        if (!sbWrapped && CONFIG.CPU_LIMIT_PERCENT) {
            SystemUtils.startCpuWatchdog(child.pid, "sing-box", CONFIG.CPU_LIMIT_PERCENT);
        }

        // Process event handlers
        child.on("error", (err) => {
            Logger.error(`Failed to start sb: ${err.message}`);
            fs.closeSync(logFile);
        });

        child.on("exit", (code, signal) => {
            fs.closeSync(logFile);
            if (signal) {
                Logger.error(`sb terminated with signal: ${signal}`);
            } else if (code !== 0) {
                Logger.error(`sb exited with code: ${code}`);
            } else {
                Logger.info("sb stopped normally");
            }
        });

        // Verify process started successfully
        setTimeout(() => {
            if (child.exitCode === null) {
                Logger.success("sb started successfully");
            }
        }, 2000);

        return child;
    }

    /* Initialize sb service */
    static async initialize() {
        Logger.header("SB CONFIGURATION");

        // Resolve internal-only local ports dynamically (unless the
        // matching env var pins one) so a hardcoded number never collides
        // with something else already using it on a given host.
        if (CONFIG.VLESS_LOCAL_PORT === null) CONFIG.VLESS_LOCAL_PORT = await getFreePort();
        if (CONFIG.ENABLE_HTTPUPGRADE && CONFIG.VLESS_HTTPUPGRADE_LOCAL_PORT === null) {
            CONFIG.VLESS_HTTPUPGRADE_LOCAL_PORT = await getFreePort();
        }
        if (CONFIG.ENABLE_SS && CONFIG.SS_PORT === null) CONFIG.SS_PORT = await getFreePort();
        if (CONFIG.ENABLE_SOCKS && CONFIG.SOCKS_PORT === null) CONFIG.SOCKS_PORT = await getFreePort();
        if (CONFIG.ENABLE_SHADOWTLS_VLESS && CONFIG.SHADOWTLS_VLESS_PORT === null) CONFIG.SHADOWTLS_VLESS_PORT = await getFreePort();
        if (CONFIG.ENABLE_HTTP_PROXY && CONFIG.HTTP_PROXY_PORT === null) CONFIG.HTTP_PROXY_PORT = await getFreePort();
        // Display configuration
        Logger.config("Node Name", CONFIG.SB_NAME);
        Logger.config("Public port", CONFIG.SB_PORT);
        Logger.config("VLESS local", CONFIG.VLESS_LOCAL_PORT);
        Logger.config("UUID", CONFIG.SB_UUID);
        Logger.config("SNI (HY2)", CONFIG.SB_SNI);
        Logger.config("WS Path", CONFIG.WS_PATH.startsWith('/') ? CONFIG.WS_PATH : `/${CONFIG.WS_PATH}`);
        Logger.config("Domain", CONFIG.SB_DOMAIN || 'Not set');
        Logger.config("Fallback Host", CONFIG.SB_HOST);
        Logger.config("Version", CONFIG.SB_VERSION);
        Logger.config("Architecture", ARCH);

        // Setup certificates
        const certs = this.ensureCertificates();
        if (!certs.cert || !certs.key) {
            Logger.error("Certificate setup failed, skipping sb");
            return null;
        }

        // Download binary
        if (!this.ensureBinary()) {
            Logger.error("Binary download failed, skipping sb");
            return null;
        }

        // REALITY: generate/persist keypair + short_id (needs the sb binary,
        // hence done here rather than in Application.
        if (CONFIG.ENABLE_REALITY) {
            const realityKeyFile = path.join(CONFIG.FILE_PATH, "reality_keys.json");
            let keys = null;
            try {
                if (fs.existsSync(realityKeyFile)) {
                    keys = JSON.parse(fs.readFileSync(realityKeyFile, "utf8"));
                }
            } catch {
                keys = null;
            }

            if (!keys || !keys.privateKey || !keys.publicKey) {
                const gen = spawnSync(PATHS.SB_BIN, ["generate", "reality-keypair"], { encoding: "utf8" });
                const privMatch = /PrivateKey:\s*(\S+)/.exec(gen.stdout || "");
                const pubMatch = /PublicKey:\s*(\S+)/.exec(gen.stdout || "");
                if (privMatch && pubMatch) {
                    keys = { privateKey: privMatch[1], publicKey: pubMatch[1] };
                    try { fs.writeFileSync(realityKeyFile, JSON.stringify(keys)); } catch { /* ignore */ }
                } else {
                    Logger.error("Failed to generate REALITY keypair — disabling REALITY");
                    CONFIG.ENABLE_REALITY = false;
                }
            }

            if (keys) {
                CONFIG.REALITY_PRIVATE_KEY = keys.privateKey;
                CONFIG.REALITY_PUBLIC_KEY = keys.publicKey;
            }
        }

        if (CONFIG.ENABLE_REALITY && !CONFIG.REALITY_SHORT_ID) {
            const shortIdFile = path.join(CONFIG.FILE_PATH, "reality_sid.txt");
            try {
                if (fs.existsSync(shortIdFile)) {
                    CONFIG.REALITY_SHORT_ID = fs.readFileSync(shortIdFile, "utf8").trim();
                }
            } catch { /* ignore */ }
            if (!CONFIG.REALITY_SHORT_ID) {
                CONFIG.REALITY_SHORT_ID = crypto.randomBytes(4).toString("hex");
                try { fs.writeFileSync(shortIdFile, CONFIG.REALITY_SHORT_ID); } catch { /* ignore */ }
            }
        }

        if (CONFIG.ENABLE_REALITY && CONFIG.REALITY_PORT === null) {
            CONFIG.REALITY_PORT = await getFreePort();
        }

        // Create configuration and start
        this.writeConfiguration(certs.cert, certs.key);
        return this.start();
    }

    /* Generate shareable links for both Hysteria2 and VLESS-WS */
    static async generateLinks() {
        const isp = await SystemUtils.getISPInfo();
        const serverHost = await this.getServerHost();
        const insecure = process.env.EXTERNAL_CERT ? "0" : "1";

        // Hysteria2 link
        const hy2Url = `hysteria2://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.SB_PORT}/?sni=${CONFIG.SB_SNI}&obfs=salamander&obfs-password=${CONFIG.SB_OBFS_PWD}&insecure=${insecure}#${CONFIG.SB_NAME}-${isp}`;

        // VLESS-WS link (matches the requested format)
        // path without leading slash in the query to match common client expectations
        const wsPathForLink = CONFIG.WS_PATH.startsWith('/') ? CONFIG.WS_PATH.slice(1) : CONFIG.WS_PATH;
        const vlessWsUrl = `vless://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.SB_PORT}?encryption=none&security=none&type=ws&path=${encodeURIComponent(wsPathForLink)}#${CONFIG.VLESS_NAME}-${isp}`;

        state.sboxLinks = [hy2Url];
        state.vlessWsLinks = [vlessWsUrl];
        state.sboxBase64 = Buffer.from(hy2Url).toString('base64');
        state.vlessWsBase64 = Buffer.from(vlessWsUrl).toString('base64');

        let vlessHuUrl = null;
        if (CONFIG.ENABLE_HTTPUPGRADE) {
            const huPathForLink = CONFIG.HTTPUPGRADE_PATH.startsWith('/') ? CONFIG.HTTPUPGRADE_PATH.slice(1) : CONFIG.HTTPUPGRADE_PATH;
            vlessHuUrl = `vless://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.SB_PORT}?encryption=none&security=none&type=httpupgrade&path=${encodeURIComponent(huPathForLink)}#${CONFIG.HTTPUPGRADE_NAME}-${isp}`;
            state.vlessHuLinks = [vlessHuUrl];
            state.vlessHuBase64 = Buffer.from(vlessHuUrl).toString('base64');
        }

        let ssUrl = null;
        if (CONFIG.ENABLE_SS) {
            // SIP002: ss://base64(method:password)@host:port#name
            // Points at the shared public port — the TCP mux in startServer()
            // detects raw Shadowsocks bytes and forwards to 127.
            const userInfo = Buffer.from(`${CONFIG.SS_METHOD}:${CONFIG.SS_PASSWORD}`).toString('base64');
            ssUrl = `ss://${userInfo}@${serverHost}:${CONFIG.PORT}#${CONFIG.SS_NAME}-${isp}`;
            state.ssLinks = [ssUrl];
            state.ssBase64 = Buffer.from(ssUrl).toString('base64');
        }

        let socksUrl = null;
        if (CONFIG.ENABLE_SOCKS) {
            // No official URI standard for SOCKS5 — this form (plain, no
            // encryption) is understood by most clients (Clash, Shadowrocket).
            // Only meant for local/LAN use or behind another secure tunnel;
            // do not rely on it alone as a censorship-evasion link.
            // Also rides the shared public port via the same TCP mux.
            const auth = CONFIG.SOCKS_USER ? `${CONFIG.SOCKS_USER}:${CONFIG.SOCKS_PASS}@` : '';
            socksUrl = `socks5://${auth}${serverHost}:${CONFIG.PORT}#${CONFIG.SOCKS_NAME}-${isp}`;
            state.socksLinks = [socksUrl];
        }

        // ShadowTLS + VLESS — no single-URI scheme covers "wrap protocol X in
        // ShadowTLS", so alongside a best-effort vless:// URI (understood by
        // sing-box-based clients such as NekoBox/SFA/SFI/Karing that accept a
        // "shadow-tls" transport param) we also emit the raw sing-box outbound
        // JSON, which is the format every ShadowTLS-aware client actually
        // trusts — paste it straight into a client's outbounds array.
        let shadowtlsVlessUrl = null, shadowtlsVlessJson = null;
        if (CONFIG.ENABLE_SHADOWTLS_VLESS) {
            shadowtlsVlessUrl = `vless://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.PORT}?encryption=none&security=none&type=tcp&headerType=none&shadow-tls=1&shadow-tls-sni=${encodeURIComponent(CONFIG.SHADOWTLS_VLESS_SNI)}&shadow-tls-password=${encodeURIComponent(CONFIG.SHADOWTLS_VLESS_PASSWORD)}&shadow-tls-version=3#${encodeURIComponent(CONFIG.SHADOWTLS_VLESS_NAME + '-' + isp)}`;
            shadowtlsVlessJson = JSON.stringify({
                type: "vless",
                tag: CONFIG.SHADOWTLS_VLESS_NAME,
                server: serverHost,
                server_port: CONFIG.PORT,
                uuid: CONFIG.SB_UUID,
                flow: "",
                detour: "shadowtls-vless-out",
                _detour_outbound: {
                    type: "shadowtls",
                    tag: "shadowtls-vless-out",
                    server: serverHost,
                    server_port: CONFIG.PORT,
                    version: 3,
                    password: CONFIG.SHADOWTLS_VLESS_PASSWORD,
                    tls: { enabled: true, server_name: CONFIG.SHADOWTLS_VLESS_SNI, utls: { enabled: true, fingerprint: "chrome" } }
                }
            });
            state.shadowtlsVlessLinks = [shadowtlsVlessUrl, shadowtlsVlessJson];
        }

        // Plain HTTP proxy — native sing-box "http" inbound, muxed onto the
        // shared public port by request-line shape (see startServer()).
        let httpProxyUrl = null;
        if (CONFIG.ENABLE_HTTP_PROXY) {
            const httpAuth = CONFIG.HTTP_PROXY_USER ? `${encodeURIComponent(CONFIG.HTTP_PROXY_USER)}:${encodeURIComponent(CONFIG.HTTP_PROXY_PASS)}@` : '';
            httpProxyUrl = `http://${httpAuth}${serverHost}:${CONFIG.PORT}#${encodeURIComponent(CONFIG.HTTP_PROXY_NAME + '-' + isp)}`;
            state.httpProxyLinks = [httpProxyUrl];
        }

        // VLESS + REALITY — raw TLS ClientHello, the mux forwards it to
        // 127.
        let realityUrl = null;
        if (CONFIG.ENABLE_REALITY && CONFIG.REALITY_PUBLIC_KEY) {
            realityUrl = `vless://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.PORT}?encryption=none&security=reality&flow=xtls-rprx-vision&pbk=${CONFIG.REALITY_PUBLIC_KEY}&sid=${CONFIG.REALITY_SHORT_ID}&sni=${CONFIG.REALITY_TARGET}&fp=chrome&alpn=${encodeURIComponent('http/1.1')}&type=tcp#${encodeURIComponent(CONFIG.REALITY_NAME + '-' + isp)}`;
            state.realityLinks = [realityUrl];
        }

        return {
            hy2: hy2Url, vlessWs: vlessWsUrl, vlessHu: vlessHuUrl, ss: ssUrl, socks: socksUrl,
            shadowtlsVless: shadowtlsVlessUrl, httpProxy: httpProxyUrl,
            reality: realityUrl
        };
    }
}

// XRAY-CORE MANAGER (XHTTP only)
// A second, independent proxy engine.
// official sing-box binary this project otherwise uses does not implement
// that transport (see the note the user was given in chat: XHTTP is an
// Xray-core invention, not part of upstream sing-box).
class XCoreManager {
    /* Pure-JS fallback for the case none of unzip/bsdtar/python3 are on the */
    static extractZipEntryPureJS(zipPath, entryName) {
        const buf = fs.readFileSync(zipPath);
        const EOCD_SIG = 0x06054b50;
        let eocdOffset = -1;
        // EOCD is a fixed 22-byte record at (or near) the end of the file;
        // scan backwards since a trailing comment can push it earlier.
        for (let i = buf.length - 22; i >= 0; i--) {
            if (buf.readUInt32LE(i) === EOCD_SIG) { eocdOffset = i; break; }
        }
        if (eocdOffset === -1) throw new Error("not a valid zip (EOCD not found)");

        const totalEntries = buf.readUInt16LE(eocdOffset + 10);
        let offset = buf.readUInt32LE(eocdOffset + 16); // central directory start

        for (let i = 0; i < totalEntries; i++) {
            if (buf.readUInt32LE(offset) !== 0x02014b50) throw new Error("malformed central directory");
            const method = buf.readUInt16LE(offset + 10);
            const compSize = buf.readUInt32LE(offset + 20);
            const nameLen = buf.readUInt16LE(offset + 28);
            const extraLen = buf.readUInt16LE(offset + 30);
            const commentLen = buf.readUInt16LE(offset + 32);
            const localHeaderOffset = buf.readUInt32LE(offset + 42);
            const name = buf.toString("utf8", offset + 46, offset + 46 + nameLen);

            if (name === entryName) {
                if (buf.readUInt32LE(localHeaderOffset) !== 0x04034b50) throw new Error("malformed local file header");
                const localNameLen = buf.readUInt16LE(localHeaderOffset + 26);
                const localExtraLen = buf.readUInt16LE(localHeaderOffset + 28);
                const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
                const compData = buf.subarray(dataStart, dataStart + compSize);
                if (method === 0) return compData;           // stored (no compression)
                if (method === 8) return zlib.inflateRawSync(compData); // deflate
                throw new Error(`unsupported zip compression method ${method}`);
            }
            offset += 46 + nameLen + extraLen + commentLen;
        }
        throw new Error(`entry '${entryName}' not found in zip`);
    }

    /* Extract a zip archive trying whichever tool is actually available, */
    static extractZip(zipPath, destDir) {
        const targetFile = path.join(destDir, "xray");

        const attempts = [
            { cmd: "unzip", args: ["-o", zipPath, "xray", "-d", destDir] },
            { cmd: "bsdtar", args: ["-xf", zipPath, "-C", destDir, "xray"] },
            {
                cmd: "python3",
                args: ["-c", `import zipfile; zipfile.ZipFile(${JSON.stringify(zipPath)}).extract("xray", ${JSON.stringify(destDir)})`]
            }
        ];

        for (const { cmd, args } of attempts) {
            const result = spawnSync(cmd, args);
            if (result.error && result.error.code === "ENOENT") {
                continue; // tool not installed — try the next one
            }
            if (result.status === 0 && fs.existsSync(targetFile)) {
                Logger.info(`Extracted Xray-core with '${cmd}'`);
                return true;
            }
        }

        try {
            const data = this.extractZipEntryPureJS(zipPath, "xray");
            fs.writeFileSync(targetFile, data);
            Logger.info("Extracted Xray-core with built-in zlib (no system tool needed)");
            return true;
        } catch (err) {
            Logger.warning(`Pure-JS zip fallback also failed: ${err.message}`);
        }

        return false;
    }

    /* Download and extract the Xray-core binary (zip, unlike sing-box's */
    static ensureBinary() {
        if (fs.existsSync(PATHS.XRAY_BIN)) {
            return true;
        }

        SystemUtils.ensureDirectory(PATHS.XRAY_BASE_DIR);
        Logger.info(`Downloading Xray-core (${XRAY_ARCH})...`);

        const freeMB = SystemUtils.getFreeDiskMB(PATHS.XRAY_BASE_DIR);
        if (freeMB !== null && freeMB < 100) {
            Logger.warning(`Low disk space before downloading Xray-core: ~${freeMB}MB free in ${PATHS.XRAY_BASE_DIR}. Download may fail with ENOSPC.`);
        }

        const zipPath = path.join(PATHS.XRAY_BASE_DIR, XRAY_ZIP_NAME);
        const dl = spawnSync("curl", ["-L", "-sS", "-o", zipPath, XRAY_DOWNLOAD_URL], { timeout: 60000 });
        if (dl.status !== 0 || !fs.existsSync(zipPath)) {
            Logger.error("Failed to download Xray-core");
            return false;
        }

        if (!this.extractZip(zipPath, PATHS.XRAY_BASE_DIR)) {
            Logger.error("Xray-core extraction failed — none of unzip/bsdtar/python3 worked. Install one of these on the host.");
            return false;
        }

        fs.renameSync(path.join(PATHS.XRAY_BASE_DIR, "xray"), PATHS.XRAY_BIN);
        spawnSync("chmod", ["+x", PATHS.XRAY_BIN]);
        try { fs.unlinkSync(zipPath); } catch { /* ignore cleanup errors */ }

        Logger.success("Xray-core installed successfully");
        return true;
    }

    /* Write the Xray-core config: one VLESS+XHTTP inbound on 127. */
    static writeConfiguration() {
        const xhttpPath = CONFIG.XHTTP_PATH.startsWith('/') ? CONFIG.XHTTP_PATH : `/${CONFIG.XHTTP_PATH}`;

        const config = {
            "log": { "loglevel": "warning" },
            "inbounds": [
                {
                    "tag": "xhttp-in",
                    "listen": "127.0.0.1",
                    "port": CONFIG.XRAY_LOCAL_PORT,
                    "protocol": "vless",
                    "settings": {
                        "clients": [{ "id": CONFIG.SB_UUID, "flow": "" }],
                        "decryption": "none"
                    },
                    "streamSettings": {
                        "network": "xhttp",
                        "security": "none",
                        "xhttpSettings": {
                            "path": xhttpPath,
                            "mode": CONFIG.XHTTP_MODE
                        }
                    }
                }
            ],
            "outbounds": [
                { "protocol": "freedom", "tag": "direct" }
            ]
        };

        fs.writeFileSync(PATHS.XRAY_JSON, JSON.stringify(config, null, 2));
        Logger.success(`xray config: VLESS-XHTTP 127.0.0.1:${CONFIG.XRAY_LOCAL_PORT}`);
    }

    /* Spawn xray-core with the config above; logs go to xray. */
    static start() {
        const logFile = fs.openSync(PATHS.XRAY_LOG_FILE, 'a');
        const { command: xrayCommand, args: xrayArgs, wrapped: xrayWrapped } = SystemUtils.withCpuLimit(PATHS.XRAY_BIN, ["run", "-c", PATHS.XRAY_JSON]);
        const child = spawn(xrayCommand, xrayArgs, {
            detached: false,
            stdio: ["ignore", logFile, logFile]
        });
        if (!xrayWrapped && CONFIG.CPU_LIMIT_PERCENT) {
            SystemUtils.startCpuWatchdog(child.pid, "Xray-core (XHTTP)", CONFIG.CPU_LIMIT_PERCENT);
        }

        child.on("error", (err) => Logger.error(`xray-core spawn error: ${err.message}`));
        child.on("exit", (code) => {
            if (code !== 0 && code !== null) {
                Logger.error(`xray-core exited with code ${code} — check ${PATHS.XRAY_LOG_FILE}`);
            }
        });

        return child;
    }

    /* Full setup: resolve local port, download binary, write config, spawn. */
    static async initialize() {
        if (CONFIG.XRAY_LOCAL_PORT === null) {
            CONFIG.XRAY_LOCAL_PORT = await getFreePort();
        }

        if (!this.ensureBinary()) {
            Logger.error("Xray-core binary unavailable — XHTTP disabled for this run");
            CONFIG.ENABLE_XHTTP = false;
            return null;
        }

        this.writeConfiguration();
        return this.start();
    }

    /* Build the VLESS-XHTTP share link — rides the shared public port, */
    static async generateLink() {
        if (!CONFIG.ENABLE_XHTTP) return null;

        const serverHost = await SbManager.getServerHost();
        const isp = await SystemUtils.getISPInfo();
        const xhttpPath = CONFIG.XHTTP_PATH.startsWith('/') ? CONFIG.XHTTP_PATH.slice(1) : CONFIG.XHTTP_PATH;

        const xhttpUrl = `vless://${CONFIG.SB_UUID}@${serverHost}:${CONFIG.PORT}?encryption=none&security=none&type=xhttp&path=${encodeURIComponent('/' + xhttpPath)}&mode=${CONFIG.XHTTP_MODE}#${CONFIG.XHTTP_NAME}-${isp}`;
        state.vlessXhttpLinks = [xhttpUrl];
        return xhttpUrl;
    }
}

// X MANAGER
class XManager {
    /* Create X configuration */
    static createConfiguration() {
        Logger.step("Creating X configuration");

        const config = {
            log: {
                access: '/dev/null',
                error: '/dev/null',
                loglevel: 'none'
            },
            inbounds: [
                {
                    port: CONFIG.ARGO_PORT,
                    protocol: 'vless',
                    settings: {
                        clients: [{
                            id: CONFIG.UUID,
                            flow: 'xtls-rprx-vision'
                        }],
                        decryption: 'none',
                        fallbacks: [
                            { dest: 3001 },
                            { path: "/vless-argo", dest: 3002 }
                        ]
                    },
                    streamSettings: { network: 'tcp' }
                },
                {
                    port: 3001,
                    listen: "127.0.0.1",
                    protocol: "vless",
                    settings: {
                        clients: [{ id: CONFIG.UUID }],
                        decryption: "none"
                    },
                    streamSettings: {
                        network: "ws",
                        security: "none",
                        wsSettings: { path: "/vless-argo" }
                    }
                },
                {
                    port: 3002,
                    listen: "127.0.0.1",
                    protocol: "vless",
                    settings: {
                        clients: [{ id: CONFIG.UUID, level: 0 }],
                        decryption: "none"
                    },
                    streamSettings: {
                        network: "ws",
                        security: "none",
                        wsSettings: { path: "/vless-argo" }
                    },
                    sniffing: {
                        enabled: true,
                        destOverride: ["http", "tls", "quic"],
                        metadataOnly: false
                    }
                }
            ],
            dns: {
                servers: ["https+local://8.8.8.8/dns-query"]
            },
            outbounds: [
                { protocol: "freedom", tag: "direct" },
                { protocol: "blackhole", tag: "block" }
            ]
        };

        fs.writeFileSync(PATHS.X_CONFIG, JSON.stringify(config, null, 2));
        Logger.success("X configuration created");
    }

    /* Get system architecture */
    static getSystemArchitecture() {
        const arch = os.arch();
        return (arch === 'arm' || arch === 'arm64' || arch === 'aarch64') ? 'arm' : 'amd';
    }

    /* Get files to download for current architecture */
    static getFilesForArchitecture(architecture) {
        const isArm = architecture === "arm";
        // Same mirror as the original working setup (override with BOT_URL).
        // NOTE: we no longer download a second "web" (Xray-core) binary from
        // this mirror — Argo now reuses the SAME Xray-core binary XCoreManager
        // downloads for XHTTP (see downloadAndRun() below), so only the
        // cloudflared ("bot") binary still needs fetching here.
        // one full duplicate Xray-core download (~20-30MB) whenever XHTTP and
        // Argo are both enabled, and is the practical way this project frees
        // up disk headroom for Argo on tight hosts — see the note on
        // ENABLE_ARGO for why pinning to smaller upstream binary versions is
        // the other half of that.
        const botDefault = isArm
            ? "https://arm64.ssss.nyc.mn/2go"
            : "https://amd64.ssss.nyc.mn/2go";

        return [
            { fileName: "bot", fileUrl: CONFIG.BOT_URL || botDefault }
        ];
    }

    /* Remove stale / incomplete binaries so they re-download */
    static purgeBadBinary(fileName, minBytes = 1024 * 500) {
        const p = path.join(CONFIG.FILE_PATH, fileName);
        try {
            if (fs.existsSync(p) && fs.statSync(p).size < minBytes) {
                fs.unlinkSync(p);
                Logger.warning(`Removed incomplete binary: ${fileName}`);
            }
        } catch { /* ignore */ }
    }

    /* Download and setup X components. */
    static async downloadAndRun() {
        // Ensure the shared Xray-core binary exists (no-op if XHTTP already
        // downloaded it this run).
        // its VLESS+WS fallback inbound on, so bail out early.
        if (!XCoreManager.ensureBinary()) {
            Logger.warning("X core binary missing - skipping X server");
            return;
        }

        const architecture = this.getSystemArchitecture();
        const filesToDownload = this.getFilesForArchitecture(architecture);

        if (filesToDownload.length === 0) {
            Logger.warning(`No files found for architecture: ${architecture}`);
            return;
        }

        // Drop truncated downloads from previous ENOSPC runs
        this.purgeBadBinary("bot");

        // cloudflared itself is roughly 40-50MB depending on architecture;
        // below this there's no realistic point attempting the download —
        // fail fast and clearly instead of limping into an ENOSPC mid-write.
        const ARGO_MIN_FREE_MB = 60;
        const freeMB = SystemUtils.getFreeDiskMB(CONFIG.FILE_PATH);
        if (freeMB !== null && freeMB < ARGO_MIN_FREE_MB && process.env.ARGO_FORCE !== "1") {
            Logger.error(`Not enough disk space for Argo: ~${freeMB}MB free in ${CONFIG.FILE_PATH} (cloudflared needs ~${ARGO_MIN_FREE_MB}MB+). Disabling Argo for this run — free up space, or set ARGO_FORCE=1 to attempt it anyway.`);
            CONFIG.ENABLE_ARGO = false;
            return;
        } else if (freeMB !== null && freeMB < 150) {
            Logger.warning(`Low disk space in ${CONFIG.FILE_PATH}: ~${freeMB}MB free. Cloudflared download may still fail with ENOSPC.`);
        }

        Logger.step(`Downloading cloudflared for ${architecture} architecture`);

        try {
            const downloadPromises = filesToDownload.map(file =>
                SystemUtils.downloadFile(file.fileName, file.fileUrl)
            );
            await Promise.all(downloadPromises);
            Logger.success("All files downloaded successfully");
        } catch (error) {
            Logger.warning(`X components download failed: ${error}`);
            Logger.warning("Continuing without Argo/X - Hysteria2 and VLESS-WS remain available");
        }

        const botPath = path.join(CONFIG.FILE_PATH, "bot");
        if (fs.existsSync(botPath)) {
            try { fs.chmodSync(botPath, 0o755); } catch { /* ignore */ }
        }

        // Stop previous instances so ports/logs are clean.
        // by its own binary path, and the Argo Xray-core process by its
        // CONFIG FILE path (not the shared binary's path) — the binary is
        // now also used by a possibly-concurrent XHTTP process, and matching
        // on binary path would kill that one too.
        try {
            execSync(`pkill -f "${PATHS.X_CONFIG}" 2>/dev/null || true`, { shell: true });
            execSync(`pkill -f "${botPath}" 2>/dev/null || true`, { shell: true });
        } catch { /* ignore */ }

        if (fs.existsSync(PATHS.XRAY_BIN)) {
            await this.startXCore();
            // Let Xray bind ARGO_PORT before cloudflared connects
            await new Promise((r) => setTimeout(r, 2500));
        } else {
            Logger.warning("X core binary missing - skipping X server");
            return;
        }

        if (fs.existsSync(botPath)) {
            await this.startCloudflared();
        } else {
            Logger.warning("Cloudflared binary missing - skipping Argo tunnel");
        }
    }

    /* Start X core — runs the SHARED Xray-core binary (PATHS. */
    static async startXCore() {
        const xcoreLog = path.join(CONFIG.FILE_PATH, "xcore.log");
        const cmd = `nohup "${PATHS.XRAY_BIN}" -c "${PATHS.X_CONFIG}" >> "${xcoreLog}" 2>&1 &`;
        try {
            exec(cmd);
            Logger.success("X core started");
        } catch (error) {
            Logger.error(`Failed to start X core: ${error}`);
        }
    }

    /* Start Cloudflared tunnel. */
    static async startCloudflared() {
        const botPath = path.join(CONFIG.FILE_PATH, "bot");
        if (!fs.existsSync(botPath)) {
            return;
        }

        try { fs.writeFileSync(PATHS.BOOT_LOG, ""); } catch { /* ignore */ }

        let args;
        const auth = CONFIG.ARGO_AUTH || "";

        if (/^[A-Z0-9a-z=]{120,250}$/.test(auth)) {
            args = `tunnel --edge-ip-version auto --no-autoupdate --protocol http2 run --token ${auth}`;
        } else if (/TunnelSecret/.test(auth)) {
            args = `tunnel --edge-ip-version auto --config "${CONFIG.FILE_PATH}/tunnel.yml" run`;
        } else {
            // Quick tunnel — cloudflared writes structured JSON logs to
            // logfile.
            // because cloudflared suppresses its stdout when logfile is set,
            // so the redirect captures nothing and can race with the logfile
            // writer to produce a garbled/truncated file.
            // The metrics API (/quicktunnel, /metrics) is the primary way we
            // pick up the domain; logfile + parseArgoDomainFromLog is the
            // fallback for builds that don't expose those endpoints.

            // loglevel info → the JSON log lines include the hostname
            // metrics → bind the local metrics server explicitly so
            // queryMetricsApi() can find it on a known port
            args = `tunnel --edge-ip-version auto --no-autoupdate --protocol http2 --logfile "${PATHS.BOOT_LOG}" --loglevel info --metrics 127.0.0.1:2000 --url http://127.0.0.1:${CONFIG.ARGO_PORT}`;
        }

        try {
            const cmd = `nohup "${botPath}" ${args} &`;
            exec(cmd);
            Logger.success("Cloudflared tunnel started");
        } catch (error) {
            Logger.error(`Failed to start Cloudflared: ${error}`);
        }
    }

    /* Read trycloudflare. */
    static parseArgoDomainFromLog(content) {
        if (!content) return null;

        const validHost = (h) => {
            h = (h || "").replace(/^https?:\/\//, "").split("/")[0].trim().toLowerCase();
            return h.endsWith(".trycloudflare.com") &&
                   h !== "trycloudflare.com" &&
                   h !== "fallback.trycloudflare.com"
                ? h : null;
        };

        // 1.
        for (const line of content.split("\n")) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("{")) continue;
            try {
                const obj = JSON.parse(trimmed);
                // Fields seen across cloudflared versions: url, hostname, message
                for (const key of ["url", "hostname"]) {
                    const h = validHost(obj[key]);
                    if (h) return h;
                }
                // Some builds embed the URL inside the message string
                if (typeof obj.message === "string") {
                    const m = obj.message.match(/https?:\/\/([a-z0-9-]+\.trycloudflare\.com)/i);
                    if (m) { const h = validHost(m[1]); if (h) return h; }
                }
            } catch { /* not valid JSON, skip */ }
        }

        // 2.
        const re = /(?:https?:\/\/)?([a-z0-9-]+\.trycloudflare\.com)/gi;
        let match, last = null;
        while ((match = re.exec(content)) !== null) {
            const h = validHost(match[1]);
            if (h) last = h;
        }
        return last;
    }

    /* Try to read the quick-tunnel hostname from cloudflared's local metrics */
    static async queryMetricsApi(port = 2000) {
        const base = `http://127.0.0.1:${port}`;

        // Helper: make a plain http GET with a short timeout, no retries
        const httpGet = (url) => new Promise((resolve, reject) => {
            const req = http.get(url, { timeout: 3000 }, (res) => {
                let data = "";
                res.on("data", (chunk) => { data += chunk; });
                res.on("end", () => resolve(data));
            });
            req.on("error", reject);
            req.on("timeout", () => { req.destroy(); reject(new Error("timeout")); });
        });

        // 1.
        try {
            const raw = await httpGet(`${base}/quicktunnel`);
            const json = JSON.parse(raw);
            const host = (json.hostname || "").replace(/^https?:\/\//, "").trim().toLowerCase();
            if (host && host.endsWith(".trycloudflare.com")) return host;
        } catch { /* not ready yet or endpoint absent */ }

        // 2.
        try {
            const raw = await httpGet(`${base}/metrics`);
            // Line looks like:
            // cloudflared_tunnel_user_hostnames_counts{userHostname="https://xxx.
            const m = raw.match(/userHostname="https?:\/\/([a-z0-9-]+\.trycloudflare\.com)"/i);
            if (m) return m[1].toLowerCase();
        } catch { /* not ready yet */ }

        return null;
    }

    /* Poll both the cloudflared metrics API (primary) and boot. */
    static async waitForArgoDomain(timeoutMs = 60000, intervalMs = 2000) {
        const started = Date.now();
        const metricsPorts = [2000, 2001, 2002];

        while (Date.now() - started < timeoutMs) {
            // Primary: query the local metrics/quicktunnel API
            for (const port of metricsPorts) {
                try {
                    const domain = await this.queryMetricsApi(port);
                    if (domain) return domain;
                } catch { /* keep trying */ }
            }

            // Secondary: scan the log file (catches older cloudflared builds)
            try {
                if (fs.existsSync(PATHS.BOOT_LOG)) {
                    const content = fs.readFileSync(PATHS.BOOT_LOG, "utf8");
                    const domain = this.parseArgoDomainFromLog(content);
                    if (domain) return domain;
                }
            } catch { /* keep polling */ }

            await new Promise((r) => setTimeout(r, intervalMs));
        }
        return null;
    }

    /* Extract Argo tunnel domains */
    static async extractDomains() {
        let argoDomain;

        // Named tunnel: user must set ARGO_DOMAIN
        if (CONFIG.ARGO_AUTH && CONFIG.ARGO_DOMAIN) {
            argoDomain = CONFIG.ARGO_DOMAIN;
            Logger.config("ARGO_DOMAIN", argoDomain);
            await this.generateLinks(argoDomain);
            return argoDomain;
        }

        if (CONFIG.ARGO_AUTH && !CONFIG.ARGO_DOMAIN) {
            Logger.warning("ARGO_AUTH set without ARGO_DOMAIN - cannot build Argo link host");
        }

        Logger.step("Waiting for Cloudflare quick tunnel domain (API + log)...");
        argoDomain = await this.waitForArgoDomain(60000, 2000);

        if (!argoDomain) {
            // At this point both the metrics API and the log file came up empty
            // for a full minute.
            // skip link generation entirely and surface a clear error — the
            // operator will see no Argo entry in the panel/sub rather than a
            // link that silently doesn't work.
            Logger.error("Argo domain not found after 60 s (API + log both empty). Argo links will be unavailable this run. Check boot.log and ensure cloudflared can reach Cloudflare's edge.");
            return null;
        }

        Logger.config("Argo Domain", argoDomain);
        await this.generateLinks(argoDomain);
        return argoDomain;
    }

    /* Generate X shareable links */
    static async generateLinks(argoDomain) {
        const isp = await SystemUtils.getISPInfo();
        // Always connect straight to the Argo domain we actually received
        // (no static front domain like kick.com); CFIP can still override.
        const cfip = process.env.CFIP || argoDomain;

        return new Promise((resolve) => {
            setTimeout(() => {
                const vlessLink = `vless://${CONFIG.UUID}@${cfip}:${CONFIG.CFPORT}?encryption=none&security=tls&sni=${argoDomain}&type=ws&host=${argoDomain}&path=%2Fvless-argo%3Fed%3D2560#${CONFIG.NAME}-${isp}`;

                state.xLinks = [vlessLink];
                state.xBase64 = Buffer.from(vlessLink).toString('base64');

                resolve(vlessLink);
            }, 2000);
        });
    }
}

// CLASH META CONVERTER
// Turns the hysteria2:// and vless:// links this app already generates into
// a Clash Meta / Mihomo compatible YAML config.
// have been stable across Clash Meta / Mihomo releases (no experimental keys),
// so the same output works on old and new clients alike.
class ClashConverter {
    /* Safe double-quoted YAML scalar */
    static yamlString(value) {
        return `"${String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
    }

    static safeDecode(value) {
        if (!value) return '';
        try { return decodeURIComponent(value); } catch { return value; }
    }

    /** Parse a hysteria2:// link into a Clash Meta "hysteria2" proxy block */
    static fromHysteria2(uri) {
        try {
            const u = new URL(uri);
            const name = this.safeDecode(u.hash ? u.hash.slice(1) : '') || 'Hysteria2';
            const password = this.safeDecode(u.username);
            const sni = u.searchParams.get('sni') || u.hostname;
            const obfs = u.searchParams.get('obfs') || '';
            const obfsPassword = u.searchParams.get('obfs-password') || '';
            const insecure = u.searchParams.get('insecure') === '1';

            const lines = [];
            lines.push(`  - name: ${this.yamlString(name)}`);
            lines.push(`    type: hysteria2`);
            lines.push(`    server: ${this.yamlString(u.hostname)}`);
            lines.push(`    port: ${parseInt(u.port, 10) || 443}`);
            lines.push(`    password: ${this.yamlString(password)}`);
            if (obfs) {
                lines.push(`    obfs: ${this.yamlString(obfs)}`);
                lines.push(`    obfs-password: ${this.yamlString(obfsPassword)}`);
            }
            lines.push(`    sni: ${this.yamlString(sni)}`);
            lines.push(`    skip-cert-verify: ${insecure ? 'true' : 'false'}`);
            lines.push(`    alpn:`);
            lines.push(`      - h3`);
            return { name, uri, yaml: lines.join('\n') };
        } catch {
            return null;
        }
    }

    /** Parse a vless:// link (WS, plain or TLS) into a Clash Meta "vless" proxy block */
    static fromVless(uri) {
        try {
            const u = new URL(uri);
            const name = this.safeDecode(u.hash ? u.hash.slice(1) : '') || 'VLESS';
            const uuid = this.safeDecode(u.username);
            const security = (u.searchParams.get('security') || 'none').toLowerCase();
            const netType = (u.searchParams.get('type') || 'tcp').toLowerCase();
            const isReality = security === 'reality';
            const isTls = security === 'tls' || isReality;
            const host = u.searchParams.get('host') || u.hostname;
            const sni = u.searchParams.get('sni') || host;
            const fp = u.searchParams.get('fp') || 'chrome';
            const pbk = u.searchParams.get('pbk') || '';
            const sid = u.searchParams.get('sid') || '';
            const flow = u.searchParams.get('flow') || '';
            let wsPath = u.searchParams.get('path') ? this.safeDecode(u.searchParams.get('path')) : '/';
            if (!wsPath.startsWith('/')) wsPath = `/${wsPath}`;

            const lines = [];
            lines.push(`  - name: ${this.yamlString(name)}`);
            lines.push(`    type: vless`);
            lines.push(`    server: ${this.yamlString(u.hostname)}`);
            lines.push(`    port: ${parseInt(u.port, 10) || (isTls ? 443 : 80)}`);
            lines.push(`    uuid: ${this.yamlString(uuid)}`);
            lines.push(`    udp: true`);
            lines.push(`    tls: ${isTls ? 'true' : 'false'}`);
            if (flow) lines.push(`    flow: ${this.yamlString(flow)}`);
            if (isTls) {
                lines.push(`    servername: ${this.yamlString(sni)}`);
                lines.push(`    client-fingerprint: ${this.yamlString(fp)}`);
                lines.push(`    skip-cert-verify: false`);
            }
            if (isReality && pbk) {
                lines.push(`    reality-opts:`);
                lines.push(`      public-key: ${this.yamlString(pbk)}`);
                if (sid) lines.push(`      short-id: ${this.yamlString(sid)}`);
            }
            if (netType === 'ws') {
                lines.push(`    network: ws`);
                lines.push(`    ws-opts:`);
                lines.push(`      path: ${this.yamlString(wsPath)}`);
                lines.push(`      headers:`);
                lines.push(`        Host: ${this.yamlString(host)}`);
            } else if (netType === 'httpupgrade') {
                // Mihomo/Clash-Meta represents HTTPUpgrade as network: ws
                // plus ws-opts.v2ray-http-upgrade: true (no separate type).
                lines.push(`    network: ws`);
                lines.push(`    ws-opts:`);
                lines.push(`      path: ${this.yamlString(wsPath)}`);
                lines.push(`      v2ray-http-upgrade: true`);
                lines.push(`      headers:`);
                lines.push(`        Host: ${this.yamlString(host)}`);
            } else {
                lines.push(`    network: tcp`);
            }
            return { name, uri, yaml: lines.join('\n') };
        } catch {
            return null;
        }
    }

    /** Build the full Clash Meta / Mihomo YAML from every currently active link */
    static buildYaml() {
        const proxies = [];
        for (const link of state.sboxLinks) {
            const p = this.fromHysteria2(link);
            if (p) proxies.push(p);
        }
        for (const link of state.vlessWsLinks) {
            const p = this.fromVless(link);
            if (p) proxies.push(p);
        }
        for (const link of state.vlessHuLinks) {
            const p = this.fromVless(link);
            if (p) proxies.push(p);
        }
        for (const link of state.xLinks) {
            const p = this.fromVless(link);
            if (p) proxies.push(p);
        }
        for (const link of state.realityLinks) {
            const p = this.fromVless(link);
            if (p) proxies.push(p);
        }
        // ShadowTLS-VLESS is shipped as sing-box outbound JSON (see
        // state.shadowtlsVlessLinks[1] / SbManager.generateLinks) rather than
        // a plain URI, since Clash Meta / Mihomo can't express a
        // ShadowTLS-wrapped detour the same way — intentionally left out of
        // the Clash export; use the sing-box JSON (panel page / /sub/sb/raw)
        // with a sing-box-based client instead.

        if (proxies.length === 0) {
            return `# Xray-Sing - no active nodes yet.\n# Reload this URL once Xray-Sing has finished starting.\nproxies: []\n`;
        }

        // De-duplicate names so Clash doesn't choke on repeats
        const seen = new Map();
        for (const p of proxies) {
            const count = seen.get(p.name) || 0;
            seen.set(p.name, count + 1);
            if (count > 0) p.name = `${p.name}-${count + 1}`;
        }

        const names = proxies.map((p) => this.yamlString(p.name));
        const proxyBlock = proxies.map((p) => p.yaml).join('\n');
        const groupProxies = names.map((n) => `      - ${n}`).join('\n');

        return `# Xray-Sing - Clash Meta / Mihomo subscription
# Generated ${new Date().toISOString()}
mixed-port: 7890
allow-lan: true
mode: rule
log-level: info
ipv6: true
unified-delay: true
tcp-concurrent: true
external-controller: 127.0.0.1:9090
dns:
  enable: true
  ipv6: true
  default-nameserver:
    - 223.5.5.5
    - 1.1.1.1
  nameserver:
    - https://dns.alidns.com/dns-query
    - https://doh.pub/dns-query

proxies:
${proxyBlock}

proxy-groups:
  - name: "PROXY"
    type: select
    proxies:
${groupProxies}
      - DIRECT
  - name: "auto"
    type: url-test
    tolerance: 50
    interval: 300
    url: "http://www.gstatic.com/generate_204"
    proxies:
${groupProxies}

rules:
  - MATCH,PROXY
`;
    }
}

// ========== HTTP SERVER ==========
class HttpServer {
    /**
     * Create Express application (plain HTTP panel)
     */
    static createApp() {
        const app = express();

        const servePage = (req, res) => this.sendSubscriptionPage(req, res);
        app.get("/", servePage);
        app.get(`/${CONFIG.SUB_PATH}`, servePage);
        app.get("/sub", servePage);

        // Raw subscription content — this is the URL to paste into clients
        // (v2rayN, NekoBox, sing-box, Hiddify, Shadowrocket, Streisand, ...).
        // Returns ALL currently-active links, base64-encoded, one per line.
        const serveRawSub = (req, res) => this.sendSubscriptionRaw(res, "all");
        app.get(`/${CONFIG.SUB_PATH}/base64`, serveRawSub);
        app.get(`/${CONFIG.SUB_PATH}/raw`, serveRawSub);

        // Per-core subscriptions — now that two engines are involved (native
        // sing-box for Hysteria2/VLESS-WS/ShadowTLS/SS/SOCKS, and
        // Xray-core for the Cloudflare Argo tunnel + XHTTP), split them out so
        // a client can subscribe to just the core it wants.
        app.get(`/${CONFIG.SUB_PATH}/sb/base64`, (req, res) => this.sendSubscriptionRaw(res, "sb"));
        app.get(`/${CONFIG.SUB_PATH}/sb/raw`, (req, res) => this.sendSubscriptionRaw(res, "sb"));
        app.get(`/${CONFIG.SUB_PATH}/xray/base64`, (req, res) => this.sendSubscriptionRaw(res, "xray"));
        app.get(`/${CONFIG.SUB_PATH}/xray/raw`, (req, res) => this.sendSubscriptionRaw(res, "xray"));

        // Clash Meta / Mihomo subscription — full YAML config, works with every
        // Clash Meta build (stable proxy fields only, no experimental keys).
        const serveClashSub = (req, res) => this.sendSubscriptionClash(req, res);
        app.get(`/${CONFIG.SUB_PATH}/clash`, serveClashSub);
        app.get(`/${CONFIG.SUB_PATH}/clash.yaml`, serveClashSub);

        app.get("/health", (req, res) => {
            res.json({
                ok: true,
                hy2: !!state.sbProcess,
                port: CONFIG.SB_PORT,
                vlessLocal: CONFIG.VLESS_LOCAL_PORT
            });
        });

        // ---------- VLESS + XHTTP: reverse-proxy to Xray-core ----------
        // XHTTP is plain HTTP request/response (chunked POST for upload,
        // long-lived GET for download) — no "Connection: Upgrade" header,
        // so it never touches the 'upgrade' handler; it arrives here as an
        // ordinary request and gets streamed straight through, both ways,
        // to the local Xray-core inbound.
        if (CONFIG.ENABLE_XHTTP) {
            const xhttpPrefix = CONFIG.XHTTP_PATH.startsWith('/') ? CONFIG.XHTTP_PATH : `/${CONFIG.XHTTP_PATH}`;
            app.use(xhttpPrefix, (req, res) => {
                const proxyReq = http.request({
                    hostname: "127.0.0.1",
                    port: CONFIG.XRAY_LOCAL_PORT,
                    path: req.originalUrl,
                    method: req.method,
                    headers: req.headers
                }, (proxyRes) => {
                    res.writeHead(proxyRes.statusCode, proxyRes.headers);
                    proxyRes.pipe(res);
                });
                proxyReq.on("error", () => { try { res.destroy(); } catch { /* ignore */ } });
                req.on("error", () => { try { proxyReq.destroy(); } catch { /* ignore */ } });
                req.pipe(proxyReq);
            });
        }

        return app;
    }

    /**
     * Start public HTTP server + WebSocket proxy to local VLESS
     * + a raw-TCP multiplexer so Shadowsocks/SOCKS5 can share the
     * SAME public port (Katabump's free plan only grants 1 allocation).
     *
     * How the mux decides where a new connection goes, by peeking at
     * its first bytes before anything else touches the socket:
     *   - starts with 0x05                -> SOCKS5 handshake  -> 127.0.0.1:SOCKS_PORT
     *   - not an HTTP method line (ASCII)  -> Shadowsocks       -> 127.0.0.1:SS_PORT
     *   - otherwise                        -> hand off to the HTTP/WS server
     *                                          (panel + VLESS-WS), unchanged
     * This only multiplexes TCP; Hysteria2 keeps using the same port
     * number over UDP separately (already true before this change).
     */
    static startServer() {
        const app = this.createApp();
        const httpServer = http.createServer(app);

        const wsPathNorm = (CONFIG.WS_PATH.startsWith('/') ? CONFIG.WS_PATH : `/${CONFIG.WS_PATH}`).replace(/\/+$/, '') || '/';
        const huPathNorm = (CONFIG.HTTPUPGRADE_PATH.startsWith('/') ? CONFIG.HTTPUPGRADE_PATH : `/${CONFIG.HTTPUPGRADE_PATH}`).replace(/\/+$/, '') || '/';

        httpServer.on("upgrade", (req, socket, head) => {
            try {
                const urlPath = (req.url || "/").split("?")[0].replace(/\/+$/, '') || '/';
                const matches = (base) =>
                    urlPath === base || urlPath === base + '/' || decodeURIComponent(urlPath) === base;

                let backendPort;
                if (matches(wsPathNorm)) {
                    backendPort = CONFIG.VLESS_LOCAL_PORT;
                } else if (CONFIG.ENABLE_HTTPUPGRADE && matches(huPathNorm)) {
                    backendPort = CONFIG.VLESS_HTTPUPGRADE_LOCAL_PORT;
                }

                if (!backendPort) {
                    socket.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");
                    socket.destroy();
                    return;
                }

                // Pipe client socket ↔ local VLESS backend (WS or HTTPUpgrade)
                const target = net.connect(backendPort, "127.0.0.1", () => {
                    // Rebuild the HTTP upgrade request for the backend
                    let reqLines = `${req.method} ${req.url} HTTP/${req.httpVersion}\r\n`;
                    for (let i = 0; i < req.rawHeaders.length; i += 2) {
                        reqLines += `${req.rawHeaders[i]}: ${req.rawHeaders[i + 1]}\r\n`;
                    }
                    reqLines += "\r\n";
                    target.write(reqLines);
                    if (head && head.length) target.write(head);

                    socket.pipe(target);
                    target.pipe(socket);
                });

                target.on("error", () => {
                    try { socket.destroy(); } catch { /* ignore */ }
                });
                socket.on("error", () => {
                    try { target.destroy(); } catch { /* ignore */ }
                });
            } catch {
                try { socket.destroy(); } catch { /* ignore */ }
            }
        });

        // ---------- Raw TCP mux in front of everything ----------
        const bridge = (socket, firstChunk, port, label) => {
            const target = net.connect(port, "127.0.0.1", () => {
                target.write(firstChunk);
                socket.pipe(target);
                target.pipe(socket);
                socket.resume();
            });
            target.on("error", () => {
                Logger.error(`${label} backend unreachable on 127.0.0.1:${port}`);
                try { socket.destroy(); } catch { /* ignore */ }
            });
            socket.on("error", () => {
                try { target.destroy(); } catch { /* ignore */ }
            });
        };

        const frontServer = net.createServer((socket) => {
            socket.once("data", (chunk) => {
                socket.pause();

                if (CONFIG.ENABLE_SOCKS && chunk.length >= 2 && chunk[0] === 0x05) {
                    bridge(socket, chunk, CONFIG.SOCKS_PORT, "SOCKS5");
                    return;
                }

                // Raw TLS ClientHello (record type 0x16, TLS 1.0-1.3 "version"
                // byte 0x03) — ShadowTLS-VLESS and REALITY
                // look identical at this point (that's the whole point —
                // real TLS to a passive/active observer); the SNI inside the
                // still-plaintext ClientHello is what tells them apart, same
                // as REALITY used to be routed here before it was removed
                // (REALITY's handshake is fingerprinted/blocked in Iran).
                if (chunk.length >= 3 && chunk[0] === 0x16 && chunk[1] === 0x03) {
                    const sni = extractSNI(chunk);
                    let target = null;
                    if (CONFIG.ENABLE_SHADOWTLS_VLESS && sni === CONFIG.SHADOWTLS_VLESS_SNI) {
                        target = [CONFIG.SHADOWTLS_VLESS_PORT, "ShadowTLS-VLESS"];
                    } else if (CONFIG.ENABLE_REALITY && sni === CONFIG.REALITY_TARGET) {
                        target = [CONFIG.REALITY_PORT, "REALITY"];
                    } else if (CONFIG.ENABLE_REALITY) {
                        // Unknown/no SNI match: REALITY itself safely falls back
                        // to a real handshake with its own decoy site for anyone
                        // without the right key, so default here (kept as the
                        // primary default since it predates ShadowTLS).
                        target = [CONFIG.REALITY_PORT, "REALITY(fallback)"];
                    } else if (CONFIG.ENABLE_SHADOWTLS_VLESS) {
                        target = [CONFIG.SHADOWTLS_VLESS_PORT, "ShadowTLS-VLESS(fallback)"];
                    }
                    if (target) {
                        bridge(socket, chunk, target[0], target[1]);
                        return;
                    }
                }

                // Plain HTTP proxy (RFC 7231 CONNECT, or absolute-form request
                // lines like "GET http://example.com/ HTTP/1.1") — forwarded to
                // sing-box's own "http" inbound. Must be checked before the
                // generic hand-off below so Express doesn't try (and fail) to
                // route a proxy request as one of its own paths.
                if (CONFIG.ENABLE_HTTP_PROXY) {
                    const head = chunk.toString("latin1", 0, Math.min(chunk.length, 2048));
                    const isConnect = /^CONNECT /.test(head);
                    const isAbsoluteForm = /^(GET|POST|PUT|HEAD|OPTIONS|DELETE|PATCH|TRACE) https?:\/\//.test(head);
                    if (isConnect || isAbsoluteForm) {
                        bridge(socket, chunk, CONFIG.HTTP_PROXY_PORT, "HTTP-proxy");
                        return;
                    }
                }

                const looksLikeHttp = /^(GET|POST|PUT|HEAD|OPTIONS|DELETE|PATCH|TRACE) /.test(
                    chunk.toString("latin1", 0, Math.min(chunk.length, 8))
                );

                if (!looksLikeHttp && CONFIG.ENABLE_SS) {
                    bridge(socket, chunk, CONFIG.SS_PORT, "Shadowsocks");
                    return;
                }

                // Not SOCKS5/Shadowsocks (or they're disabled) — hand off
                // to the existing HTTP/WS server (panel + VLESS-WS).
                socket.unshift(chunk);
                httpServer.emit("connection", socket);
                socket.resume();
            });

            socket.on("error", () => { /* ignore — client disconnected before sending data */ });
        });

        return new Promise((resolve, reject) => {
            frontServer.listen(CONFIG.PORT, "0.0.0.0", () => {
                Logger.success(`HTTP panel + WS proxy on 0.0.0.0:${CONFIG.PORT}`);
                if (CONFIG.ENABLE_SS || CONFIG.ENABLE_SOCKS) {
                    Logger.success(`SS/SOCKS5 muxed onto the same port ${CONFIG.PORT} (TCP only)`);
                }
                if (CONFIG.ENABLE_REALITY || CONFIG.ENABLE_SHADOWTLS_VLESS) {
                    Logger.success(`REALITY/ShadowTLS muxed onto the same port ${CONFIG.PORT} (routed by SNI)`);
                }
                if (CONFIG.ENABLE_HTTP_PROXY) {
                    Logger.success(`HTTP proxy muxed onto the same port ${CONFIG.PORT}`);
                }
                Logger.info(`Open: http://YOUR_IP:${CONFIG.PORT}/${CONFIG.SUB_PATH}`);
                resolve(frontServer);
            });
            frontServer.on("error", (err) => {
                Logger.error(`HTTP server error: ${err.message}`);
                reject(err);
            });
        });
    }

    /**
     * Collect currently-active links into a single newline-separated
     * subscription body. `scope` selects which engine's links to include:
     *   "all"  -> everything (default, backward compatible with /sub/base64)
     *   "sb"   -> native sing-box core only (Hysteria2, VLESS-WS/HTTPUpgrade,
     *             SS, SOCKS5, ShadowTLS-VLESS)
     *   "xray" -> Xray-core only (VLESS-Argo, VLESS-XHTTP)
     */
    static buildSubscriptionContent(scope = "all") {
        const sbLinks = [
            ...state.sboxLinks,
            ...state.vlessWsLinks,
            ...state.vlessHuLinks,
            ...state.ssLinks,
            ...state.socksLinks,
            ...state.realityLinks,
            ...state.shadowtlsVlessLinks,
            ...state.httpProxyLinks
        ];
        const xrayLinks = [
            ...state.xLinks,
            ...state.vlessXhttpLinks
        ];

        let links;
        if (scope === "sb") links = sbLinks;
        else if (scope === "xray") links = xrayLinks;
        else links = [...sbLinks, ...xrayLinks];

        return links.filter(Boolean).join('\n');
    }

    /**
     * Build the absolute subscription URL from the incoming request so it
     * works correctly whether accessed by IP, domain, or behind a proxy.
     */
    static getSubscriptionUrl(req) {
        const host = (req && req.headers && req.headers.host) || `127.0.0.1:${CONFIG.PORT}`;
        const proto = (req && req.protocol) || 'http';
        return `${proto}://${host}/${CONFIG.SUB_PATH}/base64`;
    }

    /** Same as getSubscriptionUrl but for the Clash Meta / Mihomo YAML endpoint */
    static getClashSubscriptionUrl(req) {
        const host = (req && req.headers && req.headers.host) || `127.0.0.1:${CONFIG.PORT}`;
        const proto = (req && req.protocol) || 'http';
        return `${proto}://${host}/${CONFIG.SUB_PATH}/clash`;
    }

    /**
     * Serve the raw subscription content — a base64 blob of all active links,
     * one per line before encoding. This is the URL you paste into a client's
     * "Add subscription" field (v2rayN, NekoBox, sing-box, Hiddify, Shadowrocket,
     * Streisand, etc). Plain Clash needs a converter (e.g. subconverter) since
     * it doesn't parse vless:// / hysteria2:// URIs natively.
     */
    static sendSubscriptionRaw(res, scope = "all") {
        const content = this.buildSubscriptionContent(scope);
        const b64 = Buffer.from(content, 'utf8').toString('base64');
        res.set('Content-Type', 'text/plain; charset=utf-8');
        res.set('Cache-Control', 'no-store');
        // Hint some clients (Shadowrocket/v2rayN) use to auto-refresh the sub
        res.set('Profile-Update-Interval', '12');
        res.set('Content-Disposition', `inline; filename="subscription-${scope}"`);
        res.send(b64);
    }

    /**
     * Serve the Clash Meta / Mihomo YAML config. Add ?download=1 to force a
     * file download instead of an inline response.
     */
    static sendSubscriptionClash(req, res) {
        const yaml = ClashConverter.buildYaml();
        res.set('Content-Type', 'text/yaml; charset=utf-8');
        res.set('Cache-Control', 'no-store');
        res.set('Profile-Update-Interval', '12');
        const disposition = (req.query && (req.query.download === '1' || req.query.download === 'true'))
            ? 'attachment'
            : 'inline';
        res.set('Content-Disposition', `${disposition}; filename="xray-sing-clash.yaml"`);
        res.send(yaml);
    }

    /**
     * Send subscription page
     */
    static sendSubscriptionPage(req, res) {
        // Pass raw links; escaping is done inside the HTML builders
        res.send(this.generateHtml(
            state.xLinks.slice(),
            state.sboxLinks.slice(),
            state.vlessWsLinks.slice(),
            state.xBase64 || '',
            state.sboxBase64 || '',
            state.vlessWsBase64 || '',
            this.getSubscriptionUrl(req),
            this.getClashSubscriptionUrl(req)
        ));
    }

    /**
     * Escape HTML special characters
     */
    static escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    /**
     * Generate HTML page
     */
    static generateHtml(xLinks, sboxLinks, vlessWsLinks, xBase64, sboxBase64, vlessWsBase64, subUrl, clashUrl) {
        const cards = [];
        if (sboxLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'hy2',
            title: 'Hysteria2',
            subtitle: 'High-speed UDP | Brutal congestion control',
            icon: 'fa-rocket',
            accent: 'hy2',
            badges: ['UDP', 'QUIC', 'Port ' + CONFIG.SB_PORT],
            links: sboxLinks,
            base64: sboxBase64
        }));
        if (vlessWsLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'vless',
            title: 'VLESS-WS',
            subtitle: 'WebSocket over TCP | same public port',
            icon: 'fa-network-wired',
            accent: 'vless',
            badges: ['TCP', 'WebSocket', 'No TLS'],
            links: vlessWsLinks,
            base64: vlessWsBase64
        }));
        if (xLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'argo',
            title: 'VLESS Argo',
            subtitle: 'Cloudflare Tunnel | CDN edge',
            icon: 'fa-cloud',
            accent: 'argo',
            badges: ['TLS', 'CDN', 'Argo'],
            links: xLinks,
            base64: xBase64
        }));
        if (state.vlessHuLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'vless-hu',
            title: 'VLESS-HTTPUpgrade',
            subtitle: 'HTTPUpgrade over TCP | same public port',
            icon: 'fa-arrow-up-right-dots',
            accent: 'vless',
            badges: ['TCP', 'HTTPUpgrade', 'No TLS'],
            links: state.vlessHuLinks,
            base64: state.vlessHuBase64
        }));
        if (state.vlessXhttpLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'vless-xhttp',
            title: 'VLESS-XHTTP',
            subtitle: 'Xray-core | reverse-proxied on the same public port',
            icon: 'fa-diagram-project',
            accent: 'vless',
            badges: ['TCP', 'XHTTP', CONFIG.XHTTP_MODE],
            links: state.vlessXhttpLinks
        }));
        if (state.ssLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'ss',
            title: 'Shadowsocks',
            subtitle: `${this.escapeHtml(CONFIG.SS_METHOD)} | same public port`,
            icon: 'fa-key',
            accent: 'hy2',
            badges: ['TCP', 'Shadowsocks'],
            links: state.ssLinks,
            base64: state.ssBase64
        }));
        if (state.socksLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'socks',
            title: 'SOCKS5',
            subtitle: 'Unencrypted | same public port | local/LAN use recommended',
            icon: 'fa-plug',
            accent: 'hy2',
            badges: ['TCP', 'SOCKS5', 'No encryption'],
            links: state.socksLinks
        }));
        if (state.realityLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'reality',
            title: 'VLESS-REALITY',
            subtitle: `Real TLS handshake with ${this.escapeHtml(CONFIG.REALITY_TARGET)} | same public port`,
            icon: 'fa-mask',
            accent: 'vless',
            badges: ['TLS', 'REALITY', 'Camouflaged'],
            links: state.realityLinks
        }));
        if (state.shadowtlsVlessLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'shadowtls-vless',
            title: 'ShadowTLS (pure)',
            subtitle: `Real TLS handshake with ${this.escapeHtml(CONFIG.SHADOWTLS_VLESS_SNI)} | works where REALITY is filtered`,
            icon: 'fa-user-secret',
            accent: 'vless',
            badges: ['TLS', 'ShadowTLS v3', 'Camouflaged'],
            links: [state.shadowtlsVlessLinks[0]]
        }));
        if (state.httpProxyLinks.length > 0) cards.push(this.generateProtocolCard({
            id: 'http-proxy',
            title: 'HTTP Proxy',
            subtitle: 'Plain HTTP CONNECT proxy | same public port',
            icon: 'fa-globe',
            accent: 'hy2',
            badges: ['HTTP', 'CONNECT'],
            links: state.httpProxyLinks
        }));

        const activeCount = cards.length;
        const asJsArg = (s) => this.escapeHtml(JSON.stringify(s || ''));

        const subRow = (id, label, url, note) => `
    <div class="link-box">
      <div class="section-label">${this.escapeHtml(label)}</div>
      <div class="link-text">${this.escapeHtml(url)}</div>
      <div class="link-actions">
        <button class="btn btn-primary" type="button" onclick="copyText(${asJsArg(url)}, this)">
          <i class="fas fa-copy"></i> Copy link
        </button>
        <button class="btn btn-ghost" type="button" onclick="toggleQr('qr-${id}')">
          <i class="fas fa-qrcode"></i> QR code
        </button>
      </div>
      ${note ? `<div class="card-sub" style="margin-top:0.6rem">${note}</div>` : ''}
      <div class="qr-box" id="qr-${id}">
        <div class="qr-canvas" data-qr-link="${this.escapeHtml(url)}"></div>
      </div>
    </div>`;

        return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0b0f19">
<title>Xray-Sing - Nodes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<style>${this.getStyles()}</style>
</head>
<body>
<div class="bg-glow"></div>
<div class="wrap">
  <header class="hero">
    <div class="hero-top">
      <div class="logo">
        <span class="logo-mark"><i class="fas fa-shield-halved"></i></span>
        <div>
          <h1>Xray-Sing</h1>
          <p class="tagline">Multi-protocol edge node</p>
        </div>
      </div>
      <div class="status-pill online">
        <span class="dot"></span> Online | ${activeCount} protocol${activeCount === 1 ? '' : 's'}
      </div>
    </div>
    <p class="hero-desc">Copy a link into your client (v2rayN, Streisand, Hiddify, NekoBox...), or scan a QR code. Hysteria2 and VLESS-WS share public port <strong>${CONFIG.SB_PORT}</strong>.</p>
  </header>

  ${subUrl ? `
  <section class="sub-card">
    <div class="sub-card-head">
      <span class="sub-card-icon"><i class="fas fa-rss"></i></span>
      <div>
        <div class="sub-card-title">Subscription links</div>
        <div class="sub-card-sub">Add one of these as a "subscription" / "sub URL" in your client to import every active node at once.</div>
      </div>
    </div>
    ${subRow('sub-universal', 'Universal (base64) - v2rayN, NekoBox, sing-box, Hiddify, Shadowrocket, Streisand', subUrl)}
    ${clashUrl ? subRow('sub-clash', 'Clash Meta / Mihomo (YAML)', clashUrl, 'Works with every Clash Meta build. Plain (non-Meta) Clash cannot run vless/hysteria2 and is not supported.') : ''}
  </section>` : ''}

  <main class="grid">
    ${cards.length ? cards.join('') : '<div class="empty">No links generated yet. Wait a moment and refresh.</div>'}
  </main>

  <footer class="footer">
    <span>Port <code>${CONFIG.SB_PORT}</code></span>
    <span class="sep">|</span>
    <span>HY2 UDP + VLESS TCP</span>
    <span class="sep">|</span>
    <span>Xray-Sing</span>
  </footer>
</div>

<div class="toast" id="toast"><i class="fas fa-check"></i> <span id="toast-text">Copied</span></div>
<script>${this.getScript()}</script>
</body>
</html>`;
    }

    static getStyles() {
        return `
:root {
  --bg: #0b0f19;
  --surface: #121826;
  --surface2: #1a2234;
  --border: rgba(255,255,255,0.08);
  --border-hover: rgba(99,102,241,0.45);
  --text: #e8edf7;
  --muted: #8b95a8;
  --primary: #6366f1;
  --primary2: #818cf8;
  --hy2: #22d3ee;
  --vless: #a78bfa;
  --argo: #34d399;
  --ok: #10b981;
  --radius: 16px;
  --shadow: 0 20px 50px rgba(0,0,0,0.35);
  --font: 'Inter', system-ui, -apple-system, sans-serif;
  --mono: 'JetBrains Mono', ui-monospace, monospace;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
}
.bg-glow {
  position: fixed; inset: 0; pointer-events: none; z-index: 0;
  background:
    radial-gradient(ellipse 80% 50% at 20% -10%, rgba(99,102,241,0.18), transparent 50%),
    radial-gradient(ellipse 60% 40% at 90% 10%, rgba(34,211,238,0.1), transparent 45%),
    radial-gradient(ellipse 50% 30% at 50% 100%, rgba(167,139,250,0.08), transparent 40%);
}
.wrap {
  position: relative; z-index: 1;
  max-width: 1100px;
  margin: 0 auto;
  padding: 2rem 1.25rem 3rem;
}
.hero { margin-bottom: 2rem; }
.hero-top {
  display: flex; align-items: center; justify-content: space-between;
  gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem;
}
.logo { display: flex; align-items: center; gap: 0.9rem; }
.logo-mark {
  width: 48px; height: 48px; border-radius: 14px;
  display: grid; place-items: center;
  background: linear-gradient(135deg, #6366f1, #22d3ee);
  box-shadow: 0 8px 24px rgba(99,102,241,0.35);
  font-size: 1.25rem; color: #fff;
}
.logo h1 {
  font-size: 1.5rem; font-weight: 700; letter-spacing: -0.02em;
}
.tagline { color: var(--muted); font-size: 0.85rem; }
.status-pill {
  display: inline-flex; align-items: center; gap: 0.45rem;
  padding: 0.4rem 0.85rem; border-radius: 999px;
  font-size: 0.8rem; font-weight: 600;
  background: rgba(16,185,129,0.12);
  color: var(--ok);
  border: 1px solid rgba(16,185,129,0.25);
}
.status-pill .dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 3px rgba(16,185,129,0.25);
  animation: pulse 2s ease infinite;
}
@keyframes pulse {
  0%, 100% { box-shadow: 0 0 0 3px rgba(16,185,129,0.25); }
  50% { box-shadow: 0 0 0 6px rgba(16,185,129,0.08); }
}
.hero-desc {
  color: var(--muted); font-size: 0.95rem; max-width: 42rem;
}
.hero-desc strong { color: var(--text); font-weight: 600; }

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 1.25rem;
}
.empty {
  grid-column: 1 / -1;
  text-align: center; padding: 3rem;
  color: var(--muted);
  background: var(--surface);
  border: 1px dashed var(--border);
  border-radius: var(--radius);
}

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 1.35rem 1.35rem 1.2rem;
  box-shadow: var(--shadow);
  transition: border-color 0.2s, transform 0.2s;
  display: flex; flex-direction: column; gap: 1rem;
}
.card:hover { border-color: var(--border-hover); transform: translateY(-2px); }

.sub-card {
  background: linear-gradient(135deg, rgba(99,102,241,0.12), rgba(34,211,238,0.06));
  border: 1px solid var(--border-hover);
  border-radius: var(--radius);
  padding: 1.35rem;
  box-shadow: var(--shadow);
  margin-bottom: 1.5rem;
  display: flex; flex-direction: column; gap: 1rem;
}
.sub-card-head { display: flex; align-items: flex-start; gap: 0.9rem; }
.sub-card-icon {
  width: 44px; height: 44px; border-radius: 12px;
  display: grid; place-items: center; font-size: 1.1rem; flex-shrink: 0;
  background: rgba(99,102,241,0.18); color: var(--primary2);
}
.sub-card-title { font-size: 1.15rem; font-weight: 650; letter-spacing: -0.01em; }
.sub-card-sub { color: var(--muted); font-size: 0.82rem; margin-top: 0.2rem; }

.card-head { display: flex; align-items: flex-start; gap: 0.9rem; }
.card-icon {
  width: 44px; height: 44px; border-radius: 12px;
  display: grid; place-items: center; font-size: 1.1rem; flex-shrink: 0;
}
.card.hy2 .card-icon { background: rgba(34,211,238,0.12); color: var(--hy2); }
.card.vless .card-icon { background: rgba(167,139,250,0.12); color: var(--vless); }
.card.argo .card-icon { background: rgba(52,211,153,0.12); color: var(--argo); }
.card-title { font-size: 1.15rem; font-weight: 650; letter-spacing: -0.01em; }
.card-sub { color: var(--muted); font-size: 0.82rem; margin-top: 0.15rem; }

.badges { display: flex; flex-wrap: wrap; gap: 0.4rem; }
.badge {
  font-size: 0.7rem; font-weight: 600; letter-spacing: 0.02em;
  padding: 0.2rem 0.55rem; border-radius: 6px;
  background: var(--surface2); color: var(--muted);
  border: 1px solid var(--border);
}
.card.hy2 .badge.accent { color: var(--hy2); border-color: rgba(34,211,238,0.3); background: rgba(34,211,238,0.08); }
.card.vless .badge.accent { color: var(--vless); border-color: rgba(167,139,250,0.3); background: rgba(167,139,250,0.08); }
.card.argo .badge.accent { color: var(--argo); border-color: rgba(52,211,153,0.3); background: rgba(52,211,153,0.08); }

.section-label {
  font-size: 0.72rem; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.06em; color: var(--muted); margin-bottom: 0.5rem;
}

.link-box {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 0.85rem;
}
.link-text {
  font-family: var(--mono);
  font-size: 0.72rem;
  line-height: 1.5;
  word-break: break-all;
  color: #c5d0e6;
  max-height: 4.5em;
  overflow: hidden;
  margin-bottom: 0.75rem;
}
.link-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }

.btn {
  appearance: none; border: none; cursor: pointer;
  display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;
  font-family: var(--font); font-size: 0.82rem; font-weight: 600;
  padding: 0.55rem 0.9rem; border-radius: 10px;
  transition: background 0.15s, transform 0.1s, opacity 0.15s;
}
.btn:active { transform: scale(0.97); }
.btn-primary {
  background: var(--primary); color: #fff;
}
.btn-primary:hover { background: var(--primary2); }
.btn-ghost {
  background: transparent; color: var(--muted);
  border: 1px solid var(--border);
}
.btn-ghost:hover { color: var(--text); border-color: rgba(255,255,255,0.18); background: rgba(255,255,255,0.04); }
.btn.copied { background: var(--ok) !important; color: #fff !important; border-color: transparent !important; }

.base64-wrap { margin-top: 0.15rem; }
.base64-toggle {
  width: 100%; justify-content: space-between;
  background: transparent; border: 1px solid var(--border);
  color: var(--muted); border-radius: 10px; padding: 0.55rem 0.85rem;
  font-size: 0.8rem; font-weight: 600; cursor: pointer;
  display: flex; align-items: center; gap: 0.5rem;
}
.base64-toggle:hover { color: var(--text); border-color: rgba(255,255,255,0.15); }
.base64-panel {
  display: none; margin-top: 0.6rem;
  background: #0a0e16; border: 1px solid var(--border);
  border-radius: 10px; padding: 0.75rem;
}
.base64-panel.open { display: block; }
.base64-panel code {
  font-family: var(--mono); font-size: 0.68rem;
  word-break: break-all; color: #9aa8c2; display: block;
  margin-bottom: 0.65rem; line-height: 1.45;
}

.qr-box {
  display: none;
  margin-top: 0.75rem;
  padding: 1rem;
  background: #0a0e16;
  border: 1px solid var(--border);
  border-radius: 10px;
  justify-content: center;
}
.qr-box.open { display: flex; }
.qr-canvas {
  width: 176px; height: 176px;
  background: #fff;
  border-radius: 8px;
  padding: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 0.7rem; color: #333; text-align: center;
}
.qr-canvas img, .qr-canvas canvas { display: block; }

.footer {
  margin-top: 2.5rem; text-align: center;
  color: var(--muted); font-size: 0.8rem;
  display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 0.35rem;
}
.footer code {
  font-family: var(--mono); font-size: 0.78rem;
  background: var(--surface2); padding: 0.1rem 0.4rem; border-radius: 4px;
  color: var(--text);
}
.sep { opacity: 0.4; }

.toast {
  position: fixed; bottom: 1.5rem; left: 50%;
  transform: translateX(-50%) translateY(120%);
  background: #0f172a; color: #fff;
  border: 1px solid rgba(16,185,129,0.4);
  padding: 0.75rem 1.25rem; border-radius: 12px;
  display: flex; align-items: center; gap: 0.5rem;
  font-size: 0.9rem; font-weight: 600;
  box-shadow: 0 12px 40px rgba(0,0,0,0.45);
  opacity: 0; transition: transform 0.25s ease, opacity 0.25s ease;
  z-index: 1000; pointer-events: none;
}
.toast.show { transform: translateX(-50%) translateY(0); opacity: 1; }
.toast i { color: var(--ok); }

@media (max-width: 640px) {
  .wrap { padding: 1.25rem 1rem 2rem; }
  .logo h1 { font-size: 1.25rem; }
  .link-actions .btn { flex: 1; }
}
`;
    }

    static getScript() {
        return `
function copyText(text, btn) {
  const done = () => {
    const toast = document.getElementById('toast');
    const t = document.getElementById('toast-text');
    if (t) t.textContent = 'Copied to clipboard';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1800);
    if (btn) {
      const prev = btn.innerHTML;
      btn.classList.add('copied');
      btn.innerHTML = '<i class="fas fa-check"></i> Copied';
      setTimeout(() => { btn.classList.remove('copied'); btn.innerHTML = prev; }, 1600);
    }
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallback(text, done));
  } else {
    fallback(text, done);
  }
}
function fallback(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;opacity:0;left:-9999px';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); }
  catch (e) { alert('Copy failed - select the text manually'); }
  document.body.removeChild(ta);
}
function toggleBase64(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('open');
}
function toggleQr(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const opening = !el.classList.contains('open');
  el.classList.toggle('open');
  if (opening) {
    const canvas = el.querySelector('[data-qr-link]');
    if (canvas && !canvas.dataset.rendered) {
      const text = canvas.getAttribute('data-qr-link');
      if (text && window.QRCode) {
        try {
          new QRCode(canvas, {
            text: text,
            width: 176,
            height: 176,
            colorDark: '#0b0f19',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
          });
          canvas.dataset.rendered = '1';
        } catch (e) {
          canvas.textContent = 'QR generation failed';
        }
      } else if (!window.QRCode) {
        canvas.textContent = 'QR library failed to load';
      }
    }
  }
}
`;
    }

    /**
     * Unified protocol card
     */
    static generateProtocolCard({ id, title, subtitle, icon, accent, badges, links, base64 }) {
        const link = links[0] || '';
        const badgesHtml = (badges || []).map((b, i) =>
            `<span class="badge${i === 0 ? ' accent' : ''}">${this.escapeHtml(b)}</span>`
        ).join('');

        // Safe embedding into onclick="copyText(<json>, this)"
        const asJsArg = (s) => this.escapeHtml(JSON.stringify(s || ''));

        return `
<article class="card ${accent}">
  <div class="card-head">
    <div class="card-icon"><i class="fas ${icon}"></i></div>
    <div>
      <div class="card-title">${this.escapeHtml(title)}</div>
      <div class="card-sub">${this.escapeHtml(subtitle)}</div>
    </div>
  </div>
  <div class="badges">${badgesHtml}</div>
  <div>
    <div class="section-label">Connection link</div>
    <div class="link-box">
      <div class="link-text">${link ? this.escapeHtml(link) : 'Not available'}</div>
      <div class="link-actions">
        ${link ? `
        <button class="btn btn-primary" type="button" onclick="copyText(${asJsArg(link)}, this)">
          <i class="fas fa-copy"></i> Copy link
        </button>
        <button class="btn btn-ghost" type="button" onclick="copyText(${asJsArg(base64)}, this)" ${base64 ? '' : 'disabled'}>
          <i class="fas fa-code"></i> Copy Base64
        </button>
        <button class="btn btn-ghost" type="button" onclick="toggleQr('qr-${id}')">
          <i class="fas fa-qrcode"></i> QR code
        </button>` : '<span class="card-sub">Waiting for generation...</span>'}
      </div>
      ${link ? `
      <div class="qr-box" id="qr-${id}">
        <div class="qr-canvas" data-qr-link="${this.escapeHtml(link)}"></div>
      </div>` : ''}
    </div>
  </div>
  ${base64 ? `
  <div class="base64-wrap">
    <button class="base64-toggle" type="button" onclick="toggleBase64('b64-${id}')">
      <span><i class="fas fa-chevron-down"></i> Show Base64 / subscription</span>
    </button>
    <div class="base64-panel" id="b64-${id}">
      <code>${this.escapeHtml(base64)}</code>
      <button class="btn btn-ghost" type="button" onclick="copyText(${asJsArg(base64)}, this)">
        <i class="fas fa-copy"></i> Copy Base64
      </button>
    </div>
  </div>` : ''}
</article>`;
    }
}

// ========== MAIN APPLICATION ==========
class Application {
    /**
     * Initialize application
     */
    static async initialize() {
        SystemUtils.ensureDirectory(CONFIG.FILE_PATH);
        SystemUtils.ensureDirectory(PATHS.SB_BASE_DIR);

        // Persist UUID so restarts keep the same node id when UUID env is unset
        const uuidFile = path.join(CONFIG.FILE_PATH, "uuid.txt");
        if (!process.env.UUID && !process.env.SB_UUID) {
            try {
                if (fs.existsSync(uuidFile)) {
                    const saved = fs.readFileSync(uuidFile, "utf8").trim();
                    if (saved) {
                        CONFIG.UUID = saved;
                        CONFIG.SB_UUID = saved;
                        if (!process.env.WS_PATH) CONFIG.WS_PATH = saved;
                    }
                } else {
                    fs.writeFileSync(uuidFile, CONFIG.UUID);
                }
            } catch {
                // ignore
            }
        }

        // Persist OBFS password — critical: random each boot would break client links
        const obfsFile = path.join(CONFIG.FILE_PATH, "obfs.txt");
        if (CONFIG.SB_OBFS_PWD) {
            try { fs.writeFileSync(obfsFile, CONFIG.SB_OBFS_PWD); } catch { /* ignore */ }
        } else {
            try {
                if (fs.existsSync(obfsFile)) {
                    CONFIG.SB_OBFS_PWD = fs.readFileSync(obfsFile, "utf8").trim();
                }
            } catch { /* ignore */ }
            if (!CONFIG.SB_OBFS_PWD) {
                CONFIG.SB_OBFS_PWD = crypto.randomBytes(16).toString("hex");
                try { fs.writeFileSync(obfsFile, CONFIG.SB_OBFS_PWD); } catch { /* ignore */ }
            }
        }
    }

    /**
     * Start the application
     */
    static async start() {
        Logger.header("Xray-Sing starting");

        await this.initialize();
        Logger.success(`Data directory: ${CONFIG.FILE_PATH}`);
        Logger.info(`Public port: ${CONFIG.PORT}  |  Argo: ${CONFIG.ENABLE_ARGO ? "on" : "off"}`);
        if (CONFIG.CPU_LIMIT_PERCENT) {
            const viaCpulimit = SystemUtils.commandExists("cpulimit");
            Logger.info(`CPU cap: ${CONFIG.CPU_LIMIT_PERCENT}% per engine (${viaCpulimit ? "via cpulimit" : "via built-in watchdog"})`);
        }

        if (process.env.ENABLE_SYSCTL === "1" || process.env.ENABLE_SYSCTL === "true") {
            SystemUtils.applySystemOptimizations();
        }

        Logger.step("[1/4] Starting sing-box (Hysteria2 + VLESS-WS)...");
        state.sbProcess = await SbManager.initialize();
        if (state.sbProcess) {
            await SbManager.generateLinks();
            Logger.success("sing-box is running");
        } else {
            Logger.error("sing-box failed to start");
        }

        if (CONFIG.ENABLE_XHTTP) {
            Logger.step("[2/4] Starting Xray-core (VLESS-XHTTP)...");
            state.xrayProcess = await XCoreManager.initialize();
            if (state.xrayProcess) {
                await XCoreManager.generateLink();
                Logger.success("xray-core is running");
            } else {
                Logger.error("xray-core failed to start (XHTTP link will be unavailable)");
            }
        } else {
            Logger.info("[2/4] XHTTP disabled (ENABLE_XHTTP=0)");
        }

        Logger.step("[3/4] Starting HTTP panel + WS proxy...");
        await HttpServer.startServer();
        Logger.success(`Panel ready on port ${CONFIG.PORT}`);

        if (CONFIG.ENABLE_ARGO) {
            Logger.step("[4/4] Starting Xray + Cloudflare Argo...");
            try {
                XManager.createConfiguration();
                await XManager.downloadAndRun();
                await new Promise((resolve) => setTimeout(resolve, 3000));
                await XManager.extractDomains();
                if (state.xLinks.length > 0) {
                    Logger.success("Argo tunnel is ready");
                } else {
                    Logger.warning("Argo link not ready (check boot.log)");
                }
            } catch (error) {
                // Argo is optional — a failure here (e.g. disk full while
                // writing its config) must not take down sing-box/XHTTP/the
                // panel, which are already up and working at this point.
                Logger.error(`Argo/X setup failed: ${error.message} — continuing without it`);
            }
        } else {
            Logger.info("[4/4] Argo disabled (ENABLE_ARGO=0)");
        }

        await this.printAllLinks();
    }

    /**
     * Final summary for the user, then clear console after 3 minutes
     */
    static async printAllLinks() {
        const host = await SbManager.getServerHost();
        const webUrl = `http://${host}:${CONFIG.PORT}/${CONFIG.SUB_PATH}`;

        console.log("");
        Logger.header("READY");
        console.log(`${COLORS.bright}${COLORS.green}  All services are running${COLORS.reset}`);
        console.log("");
        console.log(`${COLORS.bright}  Web panel${COLORS.reset}`);
        console.log(`  ${COLORS.yellow}${webUrl}${COLORS.reset}`);
        console.log("");
        console.log(`${COLORS.bright}  Subscription (universal, base64)${COLORS.reset}`);
        console.log(`  ${COLORS.yellow}${webUrl}/base64${COLORS.reset}`);
        console.log("");
        console.log(`${COLORS.bright}  Subscription (sing-box core only)${COLORS.reset}`);
        console.log(`  ${COLORS.yellow}${webUrl}/sb/base64${COLORS.reset}`);
        console.log("");
        console.log(`${COLORS.bright}  Subscription (Xray-core / Argo only)${COLORS.reset}`);
        console.log(`  ${COLORS.yellow}${webUrl}/xray/base64${COLORS.reset}`);
        console.log("");
        console.log(`${COLORS.bright}  Subscription (Clash Meta / Mihomo)${COLORS.reset}`);
        console.log(`  ${COLORS.yellow}${webUrl}/clash${COLORS.reset}`);
        console.log("");

        if (state.sboxLinks.length > 0) {
            console.log(`${COLORS.bright}  Hysteria2${COLORS.reset}`);
            state.sboxLinks.forEach((link) => {
                console.log(`  ${COLORS.white}${link}${COLORS.reset}`);
            });
            console.log("");
        }

        if (state.vlessWsLinks.length > 0) {
            console.log(`${COLORS.bright}  VLESS-WS${COLORS.reset}`);
            state.vlessWsLinks.forEach((link) => {
                console.log(`  ${COLORS.white}${link}${COLORS.reset}`);
            });
            console.log("");
        }

        if (state.realityLinks.length > 0) {
            console.log(`${COLORS.bright}  VLESS-REALITY${COLORS.reset}`);
            state.realityLinks.forEach((link) => console.log(`  ${COLORS.white}${link}${COLORS.reset}`));
            console.log("");
        }

        if (state.shadowtlsVlessLinks.length > 0) {
            console.log(`${COLORS.bright}  ShadowTLS (pure)${COLORS.reset}`);
            console.log(`  ${COLORS.white}${state.shadowtlsVlessLinks[0]}${COLORS.reset}`);
            console.log(`  ${COLORS.dim}(sing-box outbound JSON below for chained-detour clients)${COLORS.reset}`);
            console.log(`  ${COLORS.white}${state.shadowtlsVlessLinks[1]}${COLORS.reset}`);
            console.log("");
        }

        if (state.httpProxyLinks.length > 0) {
            console.log(`${COLORS.bright}  HTTP proxy${COLORS.reset}`);
            state.httpProxyLinks.forEach((link) => console.log(`  ${COLORS.white}${link}${COLORS.reset}`));
            console.log("");
        }

        if (CONFIG.ENABLE_ARGO && state.xLinks.length > 0) {
            console.log(`${COLORS.bright}  VLESS Argo${COLORS.reset}`);
            state.xLinks.forEach((link) => {
                console.log(`  ${COLORS.white}${link}${COLORS.reset}`);
            });
            console.log("");
        }

        console.log(`${COLORS.dim}  Links also saved to: ${path.join(CONFIG.FILE_PATH, "links.txt")}${COLORS.reset}`);
        console.log(`${COLORS.dim}  Console will clear in 3 minutes...${COLORS.reset}`);
        console.log(`${COLORS.bright}${COLORS.cyan}${"=".repeat(56)}${COLORS.reset}`);
        console.log("");

        try {
            const linksFile = path.join(CONFIG.FILE_PATH, "links.txt");
            const lines = [
                `Web: ${webUrl}`,
                "",
                "=== Hysteria2 ===",
                ...state.sboxLinks,
                "",
                "=== VLESS-WS ===",
                ...state.vlessWsLinks,
                "",
                "=== VLESS-REALITY ===",
                ...state.realityLinks,
                "",
                "=== ShadowTLS (pure) ===",
                ...state.shadowtlsVlessLinks,
                "",
                "=== HTTP proxy ===",
                ...state.httpProxyLinks,
            ];
            if (CONFIG.ENABLE_ARGO && state.xLinks.length) {
                lines.push("", "=== X/Argo ===", ...state.xLinks);
            }
            fs.writeFileSync(linksFile, lines.join("\n") + "\n");
        } catch {
            // silent
        }

        // Keep timer on the event loop; clear with no further messages
        const clearTimer = setTimeout(() => {
            Logger.clearConsole();
        }, 3 * 60 * 1000);
        // Do NOT unref — must fire while the server keeps running
        if (clearTimer.ref) clearTimer.ref();
    }
}

// ========== ERROR HANDLING & SHUTDOWN ==========
function shutdown(signal) {
    try {
        if (state.sbProcess && !state.sbProcess.killed) {
            state.sbProcess.kill("SIGTERM");
        }
    } catch { /* ignore */ }
    process.exit(signal === "SIGINT" ? 130 : 0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

process.on("uncaughtException", (error) => {
    Logger.error(`Uncaught Exception: ${error.message}`);
});

process.on("unhandledRejection", (reason) => {
    Logger.error(`Unhandled Rejection: ${reason}`);
});

// ========== APPLICATION START ==========
Application.start().catch((error) => {
    Logger.error(`Application failed to start: ${error.message}`);
    process.exit(1);
});
