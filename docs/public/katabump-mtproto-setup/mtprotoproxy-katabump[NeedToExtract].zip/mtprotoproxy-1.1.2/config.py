import secrets

PORT = 443

USERS = {
    "tg": secrets.token_hex(16),
}

MODES = {
    "classic": False,
    "secure": False,
    "tls": True
}
